-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: May 24, 2021 at 12:05 PM
-- Server version: 10.4.15-MariaDB-log
-- PHP Version: 5.6.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mohitroomin_pg_rent`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `first_name` varchar(100) DEFAULT NULL,
  `last_name` varchar(100) DEFAULT NULL,
  `dob` varchar(30) DEFAULT NULL,
  `emailid` varchar(100) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `image` varchar(100) DEFAULT NULL,
  `mobile_no` varchar(25) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `city` varchar(30) DEFAULT NULL,
  `state` varchar(30) DEFAULT NULL,
  `country` varchar(30) DEFAULT NULL,
  `zip_code` varchar(15) DEFAULT NULL,
  `status` varchar(10) DEFAULT 'yes',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `is_active` int(8) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `first_name`, `last_name`, `dob`, `emailid`, `password`, `image`, `mobile_no`, `address`, `city`, `state`, `country`, `zip_code`, `status`, `created_at`, `updated_at`, `is_active`) VALUES
(1, 'Super admin', 'Dsoi', '16/08/1945', 'admin@gmail.com', '21232f297a57a5a743894a0e4a801fc3', 'images/admin_image/1.jpg', '9999098890', 'jabalpur', 'jabalpur', 'Madhya pradesh', 'india', '482002', 'yes', '2020-03-23 10:46:54', '0000-00-00 00:00:00', 1);

-- --------------------------------------------------------

--
-- Table structure for table `allotment`
--

CREATE TABLE `allotment` (
  `id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `building_id` int(11) NOT NULL,
  `room_id` int(11) NOT NULL,
  `amount` varchar(255) NOT NULL,
  `rent` varchar(255) NOT NULL,
  `from_date` date NOT NULL,
  `to_date` date NOT NULL,
  `status` int(11) NOT NULL DEFAULT 1 COMMENT '1=active 2=inactive',
  `createdat` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `allotment`
--

INSERT INTO `allotment` (`id`, `customer_id`, `employee_id`, `building_id`, `room_id`, `amount`, `rent`, `from_date`, `to_date`, `status`, `createdat`) VALUES
(1, 1, 3, 3, 91, '11500', '10000', '2020-08-01', '2020-08-01', 2, '2020-08-27 17:14:54'),
(2, 4, 3, 3, 93, '9000', '8000', '2017-11-05', '2017-12-01', 1, '2020-08-27 17:40:33'),
(3, 3, 3, 3, 90, '12500', '12000', '2018-02-10', '2018-02-14', 1, '2020-08-27 17:45:02'),
(4, 2, 3, 3, 92, '11500', '10000', '2020-08-01', '2020-08-01', 1, '2020-08-27 17:47:54'),
(5, 5, 3, 3, 86, '9500', '8000', '2019-08-30', '2019-09-01', 1, '2020-08-27 17:58:22'),
(6, 6, 3, 3, 87, '9500', '6000', '2020-08-26', '2020-09-01', 1, '2020-08-27 18:08:46'),
(7, 8, 3, 3, 88, '10000', '5000', '2020-08-26', '2020-09-01', 1, '2020-08-27 18:13:32'),
(8, 9, 3, 3, 75, '10000', '9000', '2019-12-01', '2019-12-02', 1, '2020-08-28 04:47:08'),
(9, 1, 3, 3, 91, '11500', '10000', '2020-08-01', '2020-08-01', 1, '2020-08-28 04:50:15'),
(10, 10, 3, 3, 78, '10000', '9000', '2020-08-01', '2020-08-01', 1, '2020-08-28 04:56:48'),
(11, 11, 3, 3, 80, '10000', '10000', '2020-08-01', '2020-08-01', 1, '2020-08-28 05:03:00'),
(12, 12, 3, 3, 84, '10500', '10000', '2017-01-01', '2017-01-01', 2, '2020-08-28 11:47:10'),
(13, 13, 3, 5, 121, '11500', '9000', '2020-08-24', '2020-08-24', 1, '2020-08-28 11:57:36'),
(14, 14, 3, 5, 125, '12500', '15000', '2019-10-01', '2019-10-01', 1, '2020-08-28 12:07:48'),
(15, 15, 3, 5, 127, '11000', '8000', '2020-07-23', '2020-08-23', 1, '2020-08-28 15:15:00'),
(17, 17, 3, 5, 131, '12500', '12000', '2019-08-09', '2019-08-12', 1, '2020-08-28 15:38:49'),
(18, 18, 3, 5, 132, '12500', '11500', '2020-08-28', '2020-05-23', 2, '2020-08-28 15:48:20'),
(19, 19, 3, 5, 135, '12000', '20000', '2017-08-01', '2017-08-01', 1, '2020-08-28 15:58:40'),
(20, 20, 3, 5, 137, '12000', '17500', '2018-08-02', '2018-08-02', 1, '2020-08-28 16:16:57'),
(21, 21, 3, 5, 139, '12000', '12000', '2017-02-02', '2017-02-02', 2, '2020-08-28 16:32:19'),
(22, 22, 3, 5, 140, '12000', '9000', '2020-08-01', '2020-08-01', 1, '2020-08-28 16:40:05'),
(23, 23, 3, 2, 66, '11000', '8000', '2020-08-01', '2020-08-01', 1, '2020-08-28 16:46:00'),
(27, 24, 3, 3, 82, '10000', '8000', '2014-11-10', '2014-11-10', 2, '2020-08-29 05:51:33'),
(29, 32, 3, 1, 45, '14500', '13000', '2019-03-10', '2019-03-10', 1, '2020-08-29 08:31:09'),
(30, 33, 3, 1, 46, '14500', '13000', '2019-06-18', '2019-06-18', 1, '2020-08-29 08:37:42'),
(31, 34, 3, 1, 48, '11500', '10500', '2019-09-01', '2019-09-01', 2, '2020-08-29 09:02:36'),
(32, 35, 3, 1, 54, '13000', '12500', '2018-01-01', '2018-01-01', 1, '2020-08-29 09:12:42'),
(33, 36, 3, 1, 55, '13000', '14000', '2020-01-02', '2020-01-02', 1, '2020-08-29 09:19:16'),
(34, 37, 3, 2, 58, '10500', '10000', '2019-08-01', '2019-08-01', 2, '2020-08-29 09:24:47'),
(35, 38, 3, 2, 74, '7000', '6000', '2020-08-01', '2020-08-01', 2, '2020-08-29 15:55:59'),
(36, 39, 3, 5, 130, '12000', '11500', '2017-07-22', '2017-07-22', 2, '2020-08-29 16:09:18'),
(38, 41, 3, 6, 9, '7500', '8500', '2020-07-01', '2020-07-01', 2, '2020-08-30 12:48:53'),
(39, 42, 3, 3, 85, '10500', '10500', '2019-04-29', '2019-04-29', 2, '2020-08-31 07:14:41'),
(40, 43, 3, 2, 68, '10500', '7000', '2020-09-04', '2020-09-05', 1, '2020-09-04 17:14:43'),
(41, 44, 3, 3, 77, '10000', '7000', '2020-09-05', '2020-09-05', 1, '2020-09-05 06:08:51'),
(42, 46, 3, 5, 122, '11500', '10000', '2020-09-08', '2020-09-08', 2, '2020-09-10 18:00:32'),
(43, 47, 2, 3, 95, '9000', '9000', '2020-01-01', '2020-01-01', 2, '2020-09-24 17:55:21'),
(44, 48, 2, 3, 83, '13000', '13000', '2020-01-01', '2020-01-01', 1, '2020-09-24 18:06:59'),
(45, 49, 2, 2, 59, '7000', '9000', '2020-09-29', '2020-09-29', 1, '2020-10-07 11:56:07'),
(46, 49, 2, 2, 59, '7000', '9000', '2020-09-29', '2020-09-29', 1, '2020-10-07 11:56:07'),
(47, 50, 2, 2, 58, '10500', '9000', '2020-09-27', '2020-09-27', 1, '2020-10-07 12:06:22'),
(48, 51, 2, 2, 72, '10000', '7000', '2020-10-11', '2020-10-11', 1, '2020-10-14 17:30:27'),
(49, 52, 3, 5, 128, '11000', '7000', '2020-10-18', '2020-10-19', 1, '2020-10-20 10:13:40'),
(50, 53, 3, 5, 122, '11500', '9500', '2020-10-24', '2020-10-24', 1, '2020-10-27 07:01:04'),
(51, 54, 2, 2, 74, '7000', '6500', '2020-11-17', '2020-11-17', 1, '2020-11-06 16:14:11'),
(52, 55, 2, 1, 47, '11500', '11500', '2018-01-11', '2018-01-11', 1, '2020-11-06 16:40:16'),
(53, 56, 3, 3, 82, '10000', '9000', '2019-09-01', '2019-09-01', 1, '2020-12-21 07:45:29'),
(54, 57, 3, 2, 73, '10000', '7000', '2020-12-05', '2020-12-05', 1, '2020-12-21 07:56:45');

-- --------------------------------------------------------

--
-- Table structure for table `building`
--

CREATE TABLE `building` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `address` text NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `building`
--

INSERT INTO `building` (`id`, `name`, `address`, `status`) VALUES
(1, '41D1', '41D1', 1),
(2, '41F1', '41F1', 1),
(3, '41G1', '41G1', 1),
(4, '41G2', '41G2', 1),
(5, '41G3', '41G3', 1),
(6, '40C1', '40C1', 1),
(7, 'Common', 'Common', 1),
(8, 'Noida', 'Noida Home', 1),
(9, 'GGN', 'GGN', 1),
(10, '41J1', 'J-61 sector - 41', 1);

-- --------------------------------------------------------

--
-- Table structure for table `buil_details`
--

CREATE TABLE `buil_details` (
  `id` int(11) NOT NULL,
  `Bullding_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `rent` bigint(20) NOT NULL,
  `status` int(11) NOT NULL,
  `booking_status` enum('1','2') NOT NULL COMMENT '1 for avilable 2 for booked'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `buil_details`
--

INSERT INTO `buil_details` (`id`, `Bullding_id`, `name`, `rent`, `status`, `booking_status`) VALUES
(1, 6, '40C1-G11', 11000, 1, '1'),
(2, 6, '40C1-G12', 11000, 1, '1'),
(3, 6, '40C1-G21', 8500, 1, '1'),
(4, 6, '40C1-G22', 8500, 1, '1'),
(5, 6, '40C1-G23', 8500, 1, '1'),
(6, 6, '40C1-G31', 9000, 1, '1'),
(7, 6, '40C1-G32', 9000, 1, '1'),
(8, 6, '40C1-G41', 7500, 1, '1'),
(9, 6, '40C1-G42', 7500, 1, '1'),
(10, 6, '40C1-G43', 7500, 1, '1'),
(11, 6, '40C1-G51', 11000, 1, '1'),
(12, 6, '40C1-F11', 11000, 1, '1'),
(13, 6, '40C1-F12', 11000, 1, '1'),
(14, 6, '40C1-F21', 8500, 1, '1'),
(15, 6, '40C1-F22', 8500, 1, '1'),
(16, 6, '40C1-F23', 8500, 1, '1'),
(18, 6, '40C1-F31', 9000, 1, '1'),
(21, 6, '40C1-F32', 9000, 1, '1'),
(22, 6, '40C1-F41', 7500, 1, '1'),
(23, 6, '40C1-F42', 7500, 1, '1'),
(24, 6, '40C1-F43', 7500, 1, '1'),
(25, 6, '40C1-F51', 11000, 1, '1'),
(40, 1, '41D1-F11', 20000, 1, '2'),
(41, 1, '41D1-F21', 13500, 1, '1'),
(42, 1, '41D1-F22', 13500, 1, '1'),
(43, 1, '41D1-F31', 14500, 1, '1'),
(44, 1, '41D1-F32', 14500, 1, '1'),
(45, 1, '41D1-F41', 14500, 1, '2'),
(46, 1, '41D1-F42', 14500, 1, '2'),
(47, 1, '41D1-S11', 11500, 1, '2'),
(48, 1, '41D1-S12', 11500, 1, '1'),
(49, 1, '41D1-S21', 13000, 1, '1'),
(50, 1, '41D1-S22', 13000, 1, '1'),
(51, 1, '41D1-S31', 10500, 1, '1'),
(52, 1, '41D1-S32', 10500, 1, '1'),
(53, 1, '41D1-S33', 10500, 1, '1'),
(54, 1, '41D1-S41', 13000, 1, '2'),
(55, 1, '41D1-S42', 13000, 1, '2'),
(56, 1, '41D1-S51', 11500, 1, '1'),
(57, 1, '41D1-T11', 8000, 1, '1'),
(58, 2, '41F1-G11', 10500, 1, '2'),
(59, 2, '41F1-G21', 7000, 1, '2'),
(60, 2, '41F1-G22', 7000, 1, '1'),
(61, 2, '41F1-G23', 7000, 1, '1'),
(63, 2, '41F1-G31', 8500, 1, '1'),
(64, 2, '41F1-G32', 8500, 1, '1'),
(65, 2, '41F1-G33', 8500, 1, '1'),
(66, 2, '41F1-F11', 11000, 1, '2'),
(67, 2, '41F1-F12', 11000, 1, '1'),
(68, 2, '41F1-F21', 10500, 1, '2'),
(69, 2, '41F1-F22', 10500, 1, '1'),
(70, 2, '41F1-F31', 10500, 1, '1'),
(71, 2, '41F1-F32', 10500, 1, '1'),
(72, 2, '41F1-F41', 10000, 1, '2'),
(73, 2, '41F1-F42', 10000, 1, '2'),
(74, 2, '41F1-S11', 7000, 1, '2'),
(75, 3, '41G1-G11', 10000, 1, '2'),
(76, 3, '41G1-G12', 10000, 1, '2'),
(77, 3, '41G1-G21', 10000, 1, '2'),
(78, 3, '41G1-G22', 10000, 1, '2'),
(79, 3, '41G1-G31', 10000, 1, '2'),
(80, 3, '41G1-G32', 10000, 1, '2'),
(81, 3, '41G1-G41', 10000, 1, '2'),
(82, 3, '41G1-G42', 10000, 1, '2'),
(83, 3, '41G1-F11', 13000, 1, '2'),
(84, 3, '41G1-F21', 10500, 1, '1'),
(85, 3, '41G1-F22', 10500, 1, '1'),
(86, 3, '41G1-F31', 9500, 1, '2'),
(87, 3, '41G1-F32', 9500, 1, '2'),
(88, 3, '41G1-F41', 10000, 1, '2'),
(89, 3, '41G1-F42', 10000, 1, '1'),
(90, 3, '41G1-F51', 12500, 1, '2'),
(91, 3, '41G1-S11', 11500, 1, '2'),
(92, 3, '41G1-S12', 11500, 1, '2'),
(93, 3, '41G1-S21', 9000, 1, '2'),
(94, 3, '41G1-S22', 9000, 1, '1'),
(95, 3, '41G1-S23', 9000, 1, '1'),
(96, 4, '41G2-G11', 7000, 1, '1'),
(97, 4, '41G2-G12', 7000, 1, '1'),
(98, 4, '41G2-G13', 7000, 1, '1'),
(99, 4, '41G2-G21', 9000, 1, '1'),
(100, 4, '41G2-G22', 9000, 1, '1'),
(101, 4, '41G2-G31', 9500, 1, '1'),
(102, 4, '41G2-G33', 9500, 1, '1'),
(103, 4, '41G2-F11', 8500, 1, '1'),
(104, 3, '41G2-F12', 8500, 1, '1'),
(105, 4, '41G2-F21', 9000, 1, '1'),
(106, 4, '41G2-F22', 9000, 1, '1'),
(107, 4, '41G2-F31', 10500, 1, '1'),
(108, 4, '41G2-F32', 10500, 1, '1'),
(109, 4, '41G2-F41', 9000, 1, '1'),
(110, 4, '41G2-S11', 8500, 1, '1'),
(111, 4, '41G2-S12', 8500, 1, '1'),
(112, 4, '41G2-S21', 9000, 1, '1'),
(113, 4, '41G2-S22', 9000, 1, '1'),
(114, 4, '41G2-S31', 9500, 1, '1'),
(115, 4, '41G2-S32', 9500, 1, '1'),
(116, 4, '41G2-S41', 10500, 1, '1'),
(121, 5, '41G3-G11', 11500, 1, '2'),
(122, 5, '41G3-G12', 11500, 1, '2'),
(123, 5, '41G3-G21', 12500, 1, '1'),
(124, 5, '41G3-G22', 12500, 1, '1'),
(125, 5, '41G3-G31', 12500, 1, '2'),
(126, 5, '41G3-G32', 12500, 1, '1'),
(127, 5, '41G3-F11', 11000, 1, '2'),
(128, 5, '41G3-F12', 11000, 1, '2'),
(129, 5, '41G3-F21', 12000, 1, '2'),
(130, 5, '41G3-F22', 12000, 1, '2'),
(131, 5, '41G3-F31', 12500, 1, '2'),
(132, 5, '41G3-F32', 12500, 1, '1'),
(133, 5, '41G3-S11', 11000, 1, '1'),
(134, 5, '41G3-S12', 11000, 1, '1'),
(135, 5, '41G3-S21', 12000, 1, '2'),
(136, 5, '41G3-S22', 12000, 1, '1'),
(137, 5, '41G3-S31', 12000, 1, '2'),
(138, 5, '41G3-S32', 12000, 1, '1'),
(139, 5, '41G3-S41', 12000, 1, '1'),
(140, 5, '41G3-S51', 12000, 1, '2'),
(141, 10, '41J1-G11', 11000, 1, '1'),
(142, 10, '41J1-G12', 11000, 1, '1'),
(143, 10, '41J1-G21', 9000, 1, '2'),
(144, 10, '41J1-G22', 9000, 1, '1'),
(145, 10, '41J1-G23', 9000, 1, '1'),
(146, 1, '41D1-F11', 20000, 1, '2');

-- --------------------------------------------------------

--
-- Table structure for table `complain`
--

CREATE TABLE `complain` (
  `id` int(11) NOT NULL,
  `log_id` int(11) NOT NULL,
  `log_type` int(11) NOT NULL,
  `date` varchar(255) NOT NULL,
  `building_id` int(11) NOT NULL,
  `room_id` int(11) NOT NULL,
  `com_category` int(11) NOT NULL,
  `com_subcategory` int(11) NOT NULL,
  `com_status` int(11) NOT NULL,
  `com_details` text NOT NULL,
  `asset_id` varchar(255) DEFAULT NULL,
  `model` varchar(255) DEFAULT NULL,
  `bill` varchar(255) DEFAULT NULL,
  `warranty` varchar(255) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `closure_remark` varchar(255) DEFAULT NULL,
  `closure_remark_by` varchar(255) DEFAULT NULL,
  `agreed_amount` bigint(20) DEFAULT NULL,
  `tat` int(11) DEFAULT NULL,
  `icr` varchar(255) DEFAULT NULL,
  `closed_by` int(11) DEFAULT NULL,
  `assign_vender` int(11) DEFAULT NULL,
  `pri_status` int(11) DEFAULT NULL,
  `category` int(11) DEFAULT NULL,
  `standard` int(11) DEFAULT NULL,
  `vendor_name` varchar(255) DEFAULT NULL,
  `shop_name` varchar(255) DEFAULT NULL,
  `mobile` varchar(255) DEFAULT NULL,
  `location` text NOT NULL,
  `amount` int(11) DEFAULT NULL,
  `part_details` text DEFAULT NULL,
  `material_cost` int(11) DEFAULT NULL,
  `labour_cost` int(11) DEFAULT NULL,
  `createdat` timestamp NOT NULL DEFAULT current_timestamp(),
  `re_amount` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `complain`
--

INSERT INTO `complain` (`id`, `log_id`, `log_type`, `date`, `building_id`, `room_id`, `com_category`, `com_subcategory`, `com_status`, `com_details`, `asset_id`, `model`, `bill`, `warranty`, `image`, `closure_remark`, `closure_remark_by`, `agreed_amount`, `tat`, `icr`, `closed_by`, `assign_vender`, `pri_status`, `category`, `standard`, `vendor_name`, `shop_name`, `mobile`, `location`, `amount`, `part_details`, `material_cost`, `labour_cost`, `createdat`, `re_amount`) VALUES
(10, 3, 1, '11-09-2020', 5, 140, 2, 3, 2, 'New Tubelight  Fitting', '', '', NULL, '1 year', '', '', '', 220, 0, '', 1, 0, 2, 0, NULL, '', '', '', '', 0, '', 0, 0, '2020-09-11 15:50:32', 0),
(11, 3, 1, '27-02-2021', 2, 58, 1, 0, 1, 'AC Repair', '', '', NULL, '', '', '', '', 0, 0, '', 0, 0, 0, 0, NULL, '', '', '', '', 0, '', 0, 0, '2021-02-27 17:33:12', 0),
(12, 3, 1, '27-02-2021', 5, 133, 1, 0, 1, 'AC Not Wark', '', '', NULL, '', '', '', '', 0, 0, '', 0, 0, 0, 0, NULL, '', '', '', '', 0, '', 0, 0, '2021-02-27 17:34:52', 0);

-- --------------------------------------------------------

--
-- Table structure for table `com_category`
--

CREATE TABLE `com_category` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `com_category`
--

INSERT INTO `com_category` (`id`, `name`, `status`) VALUES
(1, 'ac repair', 1),
(2, 'Electric Equipment', 1);

-- --------------------------------------------------------

--
-- Table structure for table `com_sub_category`
--

CREATE TABLE `com_sub_category` (
  `id` int(11) NOT NULL,
  `com_cat_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `com_sub_category`
--

INSERT INTO `com_sub_category` (`id`, `com_cat_id`, `name`, `status`) VALUES
(2, 2, 'microwave', 1),
(3, 2, 'Tubelight', 1);

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `pri_mobile` bigint(20) NOT NULL,
  `whatsup_no` bigint(255) NOT NULL,
  `sec_mobile` bigint(20) NOT NULL,
  `dob` varchar(255) NOT NULL,
  `address` text NOT NULL,
  `aadharcard_no` int(11) NOT NULL,
  `image` varchar(255) NOT NULL,
  `status` int(11) NOT NULL COMMENT '1=active 2=inactive 3=alloted',
  `booking_status` int(11) NOT NULL DEFAULT 1 COMMENT '1=available 2=booked 0=inactive'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`id`, `name`, `email`, `pri_mobile`, `whatsup_no`, `sec_mobile`, `dob`, `address`, `aadharcard_no`, `image`, `status`, `booking_status`) VALUES
(1, 'Saloni Rastogi', 'temp@gmail.com', 8800483459, 8800483459, 1122, '2020-08-04', 'Na', 123456, '', 1, 2),
(2, 'Vaishali', 'vaishali@Gmali.com', 8800483459, 8800483459, 9724545623, '2019-12-01', 'abcd', 12345678, '', 1, 2),
(3, 'Sara Sriwastava', 'sarasriwastava210@Gmali.com', 7836058234, 7836058234, 9870838377, '1996-04-20', 'gorakhpur', 2147483647, '', 1, 2),
(4, 'mohini yadav', 'mohini1996@Gmali.com', 8126412272, 8126412272, 9722183059, '1992-01-15', 'krishna nagar fatehpur uttar pradesh', 2147483647, '', 1, 2),
(5, 'Taniya sharma', 'taniyasharma01111@Gmali.com', 9888969779, 9888969779, 9464777929, '1997-11-01', 'house no f-16/278 amritsar punjab', 2147483647, '', 1, 2),
(6, 'Jyoti Awasthi', 'jyotiawasthi@Gmali.com', 7607849975, 7607849975, 9548761254, '2020-08-01', 'na', 123456, '', 1, 2),
(8, 'Mahima', 'mahima@1991Gmali.com', 9821116798, 9821116798, 1234567890, '2020-08-01', 'abcd', 123456, '', 1, 2),
(9, 'Priya Pandey', 'priyapandey@Gmali.com', 7985793299, 7985793299, 7985793299, '2020-08-01', 'na', 123456, '', 1, 2),
(10, 'Deepti Singh', 'deeptisingh@Gmali.com', 9650871936, 9650871936, 9650871936, '2020-08-01', 'na', 123456, '', 1, 2),
(11, 'Versha Koul', 'vershakoul@gmali.com', 8587003117, 8587003117, 8587003117, '2020-08-01', 'na', 12345, '', 1, 2),
(12, 'Vishakha Chaursia', 'vishakhachaursia@Gmali.com', 9711094582, 9711094582, 9416204542, '1998-04-02', 'panipat haryana', 12345, '', 2, 0),
(13, 'Khushboo Singh', 'khushboosingh@Gmali.com', 9654798082, 9654798082, 9654798082, '2000-01-01', 'na', 123456, '', 1, 2),
(14, 'Viveka Shahi', 'vivekashahi@gmali.com', 9821793507, 9821793507, 9821793507, '1999-01-01', 'na', 123456, '', 1, 2),
(15, 'Divya Paliwal', 'DivyaPaliwal@Gmali.com', 8529740850, 8529740850, 8529740850, '1996-04-01', 'na', 123456, '', 1, 2),
(17, 'Shaayal Mishra', 'mishrashaayal@Gmali.com', 9628461105, 9628461105, 7080118421, '1998-01-05', '170/4 aves vikas colony unnao uttar pradesh', 2147483647, '', 1, 2),
(18, 'Madhu - 10315', 'Madhu@gmali.com', 9868976377, 9868976377, 9868976377, '1995-02-01', 'na', 123456, '', 2, 0),
(19, 'Ayilya Thampuran', 'ayilyathampuran@Gmali.com', 9711141423, 9711141423, 9582505764, '1998-11-10', 'palam karoor lalam kottayam kerala', 2147483647, '', 1, 2),
(20, 'Devangi Garg', 'devangigarg@Gmali.com', 9997521114, 9997521114, 9997521114, '1993-08-23', 'sambal tigree uttar pradesh', 2147483647, '', 1, 2),
(21, 'Mandakini Kumar', 'mandakini.kukar@yahoo.com', 9910056233, 9910056233, 9650053846, '1981-11-20', 'dwarka new delhi  ', 123456, '', 2, 0),
(22, 'Jyotsana', 'Jyotsana@Gmali.com', 8899309621, 8899309621, 8899309621, '1996-03-05', 'na', 123456, '', 1, 2),
(23, 'Shivank - 10320', 'shivank@Gmali.com', 9325467956, 9325467956, 9325467956, '1995-05-01', 'na', 123456, '', 1, 2),
(24, 'Nikita Jaiswal', 'nikitajaiswal@Gmali.com', 8527110909, 8527110909, 9997819548, '1992-03-25', 'Bareilly uttar pradesh', 5643118, '', 2, 0),
(32, 'Aashrita Goel', 'aashritagoel42@Gmali.com', 7889398173, 9805054360, 9419160310, '1996-08-30', 'shir nagar udhmpur J & k', 2147483647, '', 1, 2),
(33, 'Nibya Singh - 10187', 'singhnibya@Gmali.com', 7781053168, 7781053168, 9939271501, '1999-03-11', 'Giridih jharkhand', 12345, '', 1, 2),
(34, 'Nehal Bajaj', 'nehalbajaj@Gmali.com', 8171853023, 8171853023, 8171853023, '1998-09-01', 'na', 123456, '', 2, 0),
(35, 'Anwesha Kedia', 'kediaanwesha@Gmali.com', 9205060812, 9205060812, 9205060812, '1998-11-11', 'na', 123456, '', 1, 2),
(36, 'Shelly Tomar', 'shelltomarviiib@Gmali.com', 8218186911, 8218186911, 9917484283, '2001-07-06', 'shiv vihar colony bauaut U P', 123456, '', 1, 2),
(37, 'Kritika Kaushal', 'kritkakaushal1995@Gmali.com', 8619545437, 8619545437, 8619545437, '1995-01-11', 'udaipur rajasthan', 123456, '', 2, 0),
(38, 'vivek sharma', 'viveksharma@Gmali.com', 9811928163, 9811928163, 9811928163, '1994-05-01', 'na', 123456, '', 2, 0),
(39, 'Harshita Arora', 'harshitaarora@Gmali.com', 9839792113, 9839792113, 9839792113, '1999-03-26', 'kanpur', 123456, '', 2, 0),
(41, 'Arpita Jaiswal', 'arpitajaiswal@Gmali.com', 7895884282, 7895884282, 7895884282, '1996-06-01', 'na', 123456, '', 2, 0),
(42, 'jigyasaa', 'jigyasaa@Gmali.com', 9205071079, 9205071079, 9205071079, '1999-03-01', 'na', 123456, '', 2, 0),
(43, 'Manish', 'manish@Gmali.com', 8249694186, 8249694186, 8249694186, '1995-05-02', 'na', 123456, '', 1, 2),
(44, 'Pooja Jayent Deshmukh', 'poojajayentdeshmuk@Gmali.com', 8767351698, 8767351698, 8767351698, '1994-05-01', 'na', 123456, 'uploads/5f53d8a0b6d73_DSC_0012.JPG', 1, 1),
(45, 'Visiting Guest', 'stayinclassluxurypg@gmail.com', 10000, 1000, 1000, '2020-09-01', 'Na', 0, '', 1, 1),
(46, 'Shafali Bodoni', 'shafalibodoni@Gmali.com', 9811608285, 9811608285, 9811608285, '1995-09-10', 'uttarakhand', 123456, '', 2, 0),
(47, 'Aporva Bhndari', 'aporvabhandari@gmail.com', 9416011400, 9416011400, 9416011400, '1990-01-01', 'N/A', 123456, '', 2, 0),
(48, 'Pooja', 'pooja@gmail.com', 8707341302, 8707341302, 8707341302, '1987-01-01', 'N/A', 654987, '', 1, 2),
(49, 'Zeeshan kaskar', 'zeeshankaskar@Gmali.com', 9920797229, 9920797229, 9920797229, '1987-01-01', 'na', 123456, '', 1, 2),
(50, 'Akhilesh', 'Akhilesh@gmail.com', 8130457598, 8130457598, 8130457598, '1987-01-01', 'N/A', 123456, '', 1, 2),
(51, 'V premchand', 'vpremchand@gmali.com', 7396785500, 7396785500, 7396785500, '1987-02-01', 'na', 123456, '', 1, 2),
(52, 'Apoorva Jain', 'Apoorvajain@Gmail.com', 8305805535, 8305805535, 8305805535, '1996-05-01', 'na', 123456, '', 1, 2),
(53, 'Shahi', 'shahi@Gmali.com', 8587003117, 8587003117, 8587003117, '1998-02-01', 'Na', 123456, '', 1, 2),
(54, 'Ashish', 'ashish@Gmali.com', 9854621345, 9854621345, 9854621345, '1989-03-10', 'na', 23456, '', 1, 2),
(55, 'Nehal Bajaj', 'nehalbajaj@Gmali.com', 8171853023, 8171853023, 8171853023, '1990-05-01', 'na', 123456, '', 1, 2),
(56, 'Soumya', 'soumya@Gmail.com', 9586423463, 9586423463, 9586423463, '1995-03-01', 'na', 123456, '', 1, 2),
(57, 'Hemant nagpal', 'hemantnagpal@Gmail.com', 9513731225, 9513731225, 9513731225, '1993-09-05', '124/2 dist sirha haryana 125076', 123456, '', 1, 2);

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `phone` bigint(20) NOT NULL,
  `email` varchar(255) NOT NULL,
  `address` text NOT NULL,
  `type` int(11) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`id`, `name`, `phone`, `email`, `address`, `type`, `status`) VALUES
(1, 'Mohit Gupta', 9810565610, 'gguptamohit@gmail.com', 'Na', 4, 1),
(2, 'Yogesh', 8800779299, 'stayinclassluxurypg@gmail.com', 'na', 1, 1),
(3, 'Arun', 9999098810, 'Stayinclassluxurypg@gmail.com', 'Na', 1, 1),
(4, 'Rajni Poddar', 9999098890, 'stayinclassluxurypg@gmail.com', 'NA', 1, 1),
(5, 'Suresh Gupta', 9312360821, 'stayinclassluxurypg@gmail.com', 'D157', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `emp_to_emp`
--

CREATE TABLE `emp_to_emp` (
  `id` int(11) NOT NULL,
  `transaction_id` int(11) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `other_emp_id` int(11) NOT NULL,
  `income` int(11) NOT NULL,
  `expense` int(11) NOT NULL,
  `mode` int(11) NOT NULL,
  `other_mode` int(11) NOT NULL,
  `comment` text NOT NULL,
  `payment_status` int(11) NOT NULL DEFAULT 1,
  `delete_status` int(11) NOT NULL DEFAULT 1 COMMENT '2=delete',
  `reason` text NOT NULL,
  `createdat` timestamp NOT NULL DEFAULT current_timestamp(),
  `date` date DEFAULT NULL,
  `date_diff` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `emp_to_emp`
--

INSERT INTO `emp_to_emp` (`id`, `transaction_id`, `employee_id`, `other_emp_id`, `income`, `expense`, `mode`, `other_mode`, `comment`, `payment_status`, `delete_status`, `reason`, `createdat`, `date`, `date_diff`) VALUES
(1, 1, 2, 3, 0, 3000, 1, 1, '  Cash handover to Arun by Yogesh', 1, 2, 'Test Entry', '2020-08-29 15:37:56', '2020-08-05', 24),
(2, 1, 3, 2, 3000, 0, 1, 1, '  Cash handover to Arun by Yogesh', 1, 2, 'Test Entry', '2020-08-29 15:37:56', '2020-08-05', 0),
(3, 3, 2, 3, 0, 3000, 1, 1, '  Yogesh to Arun Cash Handover Rs3000 dt 5Aug2020', 1, 1, '', '2020-08-29 15:43:55', '2020-08-05', 24),
(4, 3, 3, 2, 3000, 0, 1, 1, '  Yogesh to Arun Cash Handover Rs3000 dt 5Aug2020', 1, 1, '', '2020-08-29 15:43:55', '2020-08-05', 0),
(5, 5, 1, 3, 0, 8000, 1, 1, 'Cash handover to Arun by Mohit', 1, 1, '', '2020-09-04 16:48:35', '2020-08-16', 19),
(6, 5, 3, 1, 8000, 0, 1, 1, 'Cash handover to Arun by Mohit', 1, 1, '', '2020-09-04 16:48:35', '2020-08-16', 0),
(7, 7, 5, 3, 0, 2000, 1, 1, '  Cashhandover to Arun by SC Gupta', 1, 1, '', '2020-09-04 16:50:30', '2020-08-18', 17),
(8, 7, 3, 5, 2000, 0, 1, 1, '  Cashhandover to Arun by SC Gupta', 1, 1, '', '2020-09-04 16:50:30', '2020-08-16', 0),
(9, 9, 3, 5, 0, 20000, 1, 1, '  Cash handover to S C Gupta by Arun kumar 20000Rs', 1, 1, '', '2020-09-11 11:48:31', '2020-09-11', 0),
(10, 9, 5, 3, 20000, 0, 1, 1, '  Cash handover to S C Gupta by Arun kumar 20000Rs', 1, 1, '', '2020-09-11 11:48:31', '2020-09-11', 0),
(11, 11, 2, 5, 0, 10000, 1, 1, '  cash received on 23/09/2020', 1, 2, 'wrong entry', '2020-09-23 07:48:24', '2020-09-23', 0),
(12, 11, 5, 2, 10000, 0, 1, 1, '  cash received on 23/09/2020', 1, 2, 'wrong entry', '2020-09-23 07:48:24', '2020-09-23', 0),
(13, 13, 1, 2, 0, 1980, 1, 1, '  This is a suspense Entry posted to match Yogesh balance as on date of  online application going live', 1, 1, '', '2020-09-23 17:43:34', '2020-08-04', 50),
(14, 13, 2, 1, 1980, 0, 1, 1, '  This is a suspense Entry posted to match Yogesh balance as on date of  online application going live', 1, 1, '', '2020-09-23 17:43:34', '2020-08-04', 0),
(15, 15, 5, 2, 0, 10000, 1, 1, '  Cash handover to Yogesh by SC Gupta 10000', 1, 1, '', '2020-09-23 17:45:03', '2020-09-23', 0),
(16, 15, 2, 5, 10000, 0, 1, 1, '  Cash handover to Yogesh by SC Gupta 10000', 1, 1, '', '2020-09-23 17:45:03', '2020-09-23', 0),
(17, 17, 3, 3, 0, 3000, 1, 1, '  Cash handover to arun by yogesh 3000 date 14-10-2020', 1, 2, 'Incorrect posting', '2020-10-14 12:37:58', '2020-10-14', 0),
(18, 17, 3, 3, 3000, 0, 1, 1, '  Cash handover to arun by yogesh 3000 date 14-10-2020', 1, 2, 'Incorrect posting', '2020-10-14 12:37:58', '2020-10-14', 0),
(19, 19, 2, 1, 0, 30000, 1, 1, 'cash hand over mohit sir by yogesh 30000', 1, 1, '', '2020-10-14 17:56:53', '2020-10-11', 3),
(20, 19, 1, 2, 30000, 0, 1, 1, 'cash hand over mohit sir by yogesh 30000', 1, 1, '', '2020-10-14 17:56:53', '2020-10-11', 0),
(21, 21, 2, 1, 0, 10000, 1, 1, '  cash hand over to mohit sir by yogesh salary ', 1, 1, '', '2020-10-14 18:02:36', '2020-10-11', 3),
(22, 21, 1, 2, 10000, 0, 1, 1, '  cash hand over to mohit sir by yogesh salary ', 1, 1, '', '2020-10-14 18:02:36', '2020-10-11', 0),
(23, 23, 3, 2, 0, 3000, 1, 1, '  cash hand over to arun by yogesh 3000', 1, 1, '', '2020-10-14 18:07:23', '2020-10-14', 0),
(24, 23, 2, 3, 3000, 0, 1, 1, '  cash hand over to arun by yogesh 3000', 1, 1, '', '2020-10-14 18:07:23', '2020-10-14', 0),
(25, 25, 4, 2, 0, 10000, 5, 1, '   Excess salary tfd to yogesh via Rajni curr ac...withdrawn by him in cash ', 1, 1, '', '2020-10-19 17:15:51', '2020-10-11', 8),
(26, 25, 2, 4, 10000, 0, 1, 5, '   Excess salary tfd to yogesh via Rajni curr ac...withdrawn by him in cash ', 1, 1, '', '2020-10-19 17:15:51', '2020-10-11', 0),
(27, 27, 4, 3, 0, 3000, 1, 1, '  cash handed over by mohit to Arun.', 1, 1, '', '2020-10-19 17:19:51', '2020-10-16', 3),
(28, 27, 3, 4, 3000, 0, 1, 1, '  cash handed over by mohit to Arun.', 1, 1, '', '2020-10-19 17:19:51', '2020-10-16', 0),
(29, 29, 3, 4, 0, 10000, 1, 1, '  Cash hand Over Arun by Rajni poddar 20000Rs date 22-10-2020', 1, 2, 'wrong Entty', '2020-10-31 15:51:15', '2020-10-22', 9),
(30, 29, 4, 3, 10000, 0, 1, 1, '  Cash hand Over Arun by Rajni poddar 20000Rs date 22-10-2020', 1, 2, 'wrong Entty', '2020-10-31 15:51:15', '2020-10-22', 0),
(31, 31, 3, 4, 0, 20000, 1, 1, '  Cash Hand over to Rajni Poddar by Arun kumar', 1, 2, 'worng entey', '2020-11-05 10:37:54', '2020-11-22', 17),
(32, 31, 4, 3, 20000, 0, 1, 1, '  Cash Hand over to Rajni Poddar by Arun kumar', 1, 2, 'worng entey', '2020-11-05 10:37:54', '2020-11-22', 0),
(33, 33, 3, 2, 0, 17000, 1, 1, '  Cash hand over to yogesh by arun', 1, 1, '', '2020-11-05 10:50:11', '2020-10-23', 13),
(34, 33, 2, 3, 17000, 0, 1, 1, '  Cash hand over to yogesh by arun', 1, 1, '', '2020-11-05 10:50:11', '2020-10-23', 0),
(35, 35, 3, 4, 0, 20000, 5, 5, '  Cash hand over to Rajni Poddar by Arun Kumar', 1, 1, '', '2020-11-05 10:55:46', '2020-10-22', 14),
(36, 35, 4, 3, 20000, 0, 5, 5, '  Cash hand over to Rajni Poddar by Arun Kumar', 1, 1, '', '2020-11-05 10:55:47', '2020-10-22', 0),
(37, 37, 2, 1, 0, 10000, 1, 1, '  Cash hand over to mohit sir by yogesh', 1, 1, '', '2020-11-06 16:53:46', '2020-10-20', 17),
(38, 37, 1, 2, 10000, 0, 1, 1, '  Cash hand over to mohit sir by yogesh', 1, 1, '', '2020-11-06 16:53:46', '2020-10-20', 0),
(39, 39, 3, 2, 0, 500, 1, 1, 'Cash hand Over to yogesh  500 by arun', 1, 1, '', '2020-11-11 06:48:38', '2020-11-05', 6),
(40, 39, 2, 3, 500, 0, 1, 1, 'Cash hand Over to yogesh  500 by arun', 1, 1, '', '2020-11-11 06:48:38', '2020-11-05', 0),
(41, 41, 3, 2, 0, 3000, 1, 1, 'Cash hand over from yogesh to arun', 1, 1, '', '2020-12-21 13:18:30', '2020-12-05', 16),
(42, 41, 2, 3, 3000, 0, 1, 1, 'Cash hand over from yogesh to arun', 1, 1, '', '2020-12-21 13:18:30', '2020-12-05', 0),
(43, 43, 3, 1, 0, 500, 1, 1, '  Cash hand over from Arun to Mohitsir', 1, 2, '', '2020-12-21 13:38:14', '2020-12-06', 15),
(44, 43, 1, 3, 500, 0, 1, 1, '  Cash hand over from Arun to Mohitsir', 1, 2, '', '2020-12-21 13:38:14', '2020-12-06', 0),
(45, 45, 3, 1, 0, 50000, 1, 1, '  Cash hand Over to mohit sir from Arun', 1, 1, '', '2020-12-21 13:43:08', '2020-12-07', 14),
(46, 45, 1, 3, 50000, 0, 1, 1, '  Cash hand Over to mohit sir from Arun', 1, 1, '', '2020-12-21 13:43:08', '2020-12-07', 0),
(47, 47, 3, 3, 0, 500, 1, 1, 'Cash hand over arun to mohit sir', 1, 2, '', '2020-12-21 13:46:40', '2020-12-06', 15),
(48, 47, 3, 3, 500, 0, 1, 1, 'Cash hand over arun to mohit sir', 1, 2, '', '2020-12-21 13:46:40', '2020-12-06', 0),
(49, 49, 3, 1, 0, 500, 1, 1, 'Cash hand over mohit sir by arun', 1, 1, '', '2020-12-21 13:49:24', '2020-12-06', 15),
(50, 49, 1, 3, 500, 0, 1, 1, 'Cash hand over mohit sir by arun', 1, 1, '', '2020-12-21 13:49:24', '2020-12-06', 0),
(51, 51, 3, 2, 0, 10000, 1, 1, '  Cash hand over arun to yogesh 10000', 1, 1, '', '2020-12-21 14:20:57', '2020-12-09', 12),
(52, 51, 2, 3, 10000, 0, 1, 1, '  Cash hand over arun to yogesh 10000', 1, 1, '', '2020-12-21 14:20:57', '2020-12-09', 0),
(53, 53, 3, 2, 0, 4000, 1, 1, '  Cash hand over arun to Yagesh', 1, 1, '', '2020-12-21 14:25:47', '2020-12-15', 6),
(54, 53, 2, 3, 4000, 0, 1, 1, '  Cash hand over arun to Yagesh', 1, 1, '', '2020-12-21 14:25:47', '2020-12-15', 0);

-- --------------------------------------------------------

--
-- Table structure for table `expense`
--

CREATE TABLE `expense` (
  `id` int(11) NOT NULL,
  `date` date NOT NULL,
  `transaction_id` int(11) DEFAULT NULL,
  `category` int(11) NOT NULL,
  `subcategory` int(11) DEFAULT NULL,
  `Item_detail` text NOT NULL,
  `paying_employee` int(11) NOT NULL,
  `amount_paid` bigint(11) NOT NULL,
  `payment_mode` int(11) NOT NULL,
  `ref_no` varchar(255) DEFAULT NULL,
  `building_id` int(11) NOT NULL,
  `room_id` varchar(255) NOT NULL,
  `room_type` bigint(11) NOT NULL,
  `sic_bill` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `vendor_bill` varchar(255) DEFAULT NULL,
  `shop_name` varchar(255) DEFAULT NULL,
  `vendor_type` varchar(255) DEFAULT NULL,
  `location` text DEFAULT NULL,
  `mobile` varchar(255) DEFAULT NULL,
  `asset_id` varchar(255) DEFAULT NULL,
  `model` varchar(255) DEFAULT NULL,
  `manufacturing_company` varchar(255) DEFAULT NULL,
  `warranty` varchar(255) DEFAULT NULL,
  `stayinclass_asset_id` varchar(255) DEFAULT NULL,
  `type` int(11) NOT NULL COMMENT '1=emp to vender ,2=vender to emp',
  `delete_status` int(11) NOT NULL DEFAULT 1 COMMENT '2=delete',
  `reason` text NOT NULL,
  `createdat` timestamp NOT NULL DEFAULT current_timestamp(),
  `date_diff` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `expense`
--

INSERT INTO `expense` (`id`, `date`, `transaction_id`, `category`, `subcategory`, `Item_detail`, `paying_employee`, `amount_paid`, `payment_mode`, `ref_no`, `building_id`, `room_id`, `room_type`, `sic_bill`, `comment`, `vendor_bill`, `shop_name`, `vendor_type`, `location`, `mobile`, `asset_id`, `model`, `manufacturing_company`, `warranty`, `stayinclass_asset_id`, `type`, `delete_status`, `reason`, `createdat`, `date_diff`) VALUES
(1, '2020-08-25', 1, 6, 22, 'Vagetables', 3, 2660, 1, '', 7, 'Common', 1, '', 'Vagetables', '', '', '', '', '', '', '', '', '', '', 1, 2, 'Test Entry', '2020-08-27 16:27:20', 2),
(2, '2020-08-29', 2, 6, 22, 'vegetables', 3, 2420, 1, '', 7, 'Common', 1, '', 'Face 2 mandi', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-08-29 17:02:27', 0),
(3, '2020-08-29', 3, 5, 52, 'Idli paste 2 kg', 3, 100, 1, '', 7, 'Common', 1, '', 'Idli paste 2 kg', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-08-29 17:23:41', 0),
(4, '2020-08-07', 4, 11, 40, 'Pulsar petrol', 3, 300, 1, '', 7, 'Common', 1, '', 'Pulsar petrol', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-08-30 05:17:53', 23),
(5, '2020-08-11', 5, 2, 6, 'plumber item', 3, 1000, 1, '', 10, '41J1', 1, '', 'plumber item', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-08-30 05:36:25', 19),
(6, '2020-08-14', 6, 11, 36, 'Pulsar bike maintenance', 3, 1750, 1, '', 7, 'Common', 1, '', 'Pulsar bike maintenance', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-08-30 05:49:56', 16),
(7, '2020-08-14', 7, 11, 40, 'Pulsar petrol', 3, 400, 1, '', 7, 'Common', 1, '', 'Pulsar petrol', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-08-30 05:59:02', 16),
(8, '2020-08-16', 8, 5, 20, 'Atta 5kg', 3, 280, 1, '', 1, '41D1', 1, '', 'Atta 5kg  41D1 ', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-08-30 15:41:33', 14),
(9, '2020-08-16', 9, 9, 32, 'Breed 1pkt', 3, 40, 1, '', 1, '41D1', 1, '', 'Breed 1pkt 41D1', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-08-30 15:45:14', 14),
(10, '2020-08-16', 10, 5, 21, 'Rajma 500gm', 3, 60, 1, '', 5, '41G3', 1, '', 'Rajma 500gm 41G3', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-08-30 15:50:14', 14),
(11, '2020-08-17', 11, 5, 21, 'Arhar 3kg 270\r\nKala Chana 3kg 180\r\nRajma 3kg 330\r\nUrad sabut 3kg 180\r\nChana dal 3 kg  270\r\nKali masoor 2kg 160\r\nLal masoor 2kg 160\r\nKabli Chana 3kg 210\r\nChawal  25kg 1300\r\nAtta 50kg 1150\r\nDeggi mirch   2Pkt 110\r\nVim Bar 6 pc 56\r\nNirma  4kg 200\r\nTea 1kg 200\r\nTotal  4776', 3, 4776, 1, '', 7, 'Common', 1, '', 'Arhar 3kg 270\r\nKala Chana 3kg 180\r\nRajma 3kg 330\r\nUrad sabut 3kg 180\r\nChana dal 3 kg  270\r\nKali masoor 2kg 160\r\nLal masoor 2kg 160\r\nKabli Chana 3kg 210\r\nChawal  25kg 1300\r\nAtta 50kg 1150\r\nDeggi mirch   2Pkt 110\r\nVim Bar 6 pc 56\r\nNirma  4kg 200\r\nTea 1kg 200\r\nTotal  4776\r\n', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-08-30 15:56:37', 13),
(12, '2020-08-17', 12, 8, 26, 'monu Salary', 3, 6000, 1, 'CV#1115', 3, '41G1', 1, '', 'monu salary  CV#1115   6000Rs', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-08-30 16:18:57', 13),
(13, '2020-08-18', 13, 2, 6, 'Ravinder plumber', 3, 1500, 1, 'CV#1116', 10, '41J1', 1, '', 'Ravinder plumber  CV#1116 1500Rs', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-08-30 16:26:13', 12),
(14, '2020-08-19', 14, 6, 22, 'Vegetables', 3, 1590, 1, '', 7, 'Common', 1, '', 'Vegetables Phase 2 sabzi mandi    1590Rs', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-08-31 07:31:15', 12),
(15, '2020-08-19', 15, 11, 40, 'Pulsar petrol', 3, 200, 1, '', 7, 'Common', 1, '', 'Pulsar petrol  19-08-2020  . 200Rs', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-08-31 07:36:10', 12),
(16, '2020-08-22', 16, 5, 20, 'noodles 2 kg', 3, 140, 1, '', 7, 'Common', 1, '', 'noodles 2 kg 22-08-2020', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-08-31 07:39:35', 9),
(17, '2020-08-24', 17, 2, 6, 'Ravinder plumber', 3, 2500, 1, 'CV#1117', 7, 'Common', 1, '', 'Ravinder plumber  All due clear   2500Rs  CV#1117 Date 24-08-2020', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-08-31 07:46:59', 7),
(18, '2020-08-25', 18, 6, 22, 'vegetables', 3, 2660, 1, '', 7, 'Common', 1, '', 'vegetables sabzi mandi phase 2', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-08-31 08:01:51', 6),
(19, '2020-08-29', 19, 5, 52, 'Dosa paste', 3, 150, 1, '', 7, 'Common', 1, '', 'Dosa paste 3 kg', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-08-31 08:05:45', 2),
(20, '2020-08-29', 20, 4, 14, 'Sweeper', 3, 100, 1, '', 2, '41F1', 1, '', 'Sweeper 41F1 nali clean', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-08-31 08:13:19', 2),
(21, '2020-09-15', 21, 14, 56, 'Cald Drank', 3, 730, 1, '', 1, '41D1', 1, '', 'Cald Drank  41D1 ', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-09-01 05:23:15', 14),
(22, '2020-09-14', 22, 13, 54, 'Stamp paper', 3, 100, 1, '', 6, '41C1', 1, '', 'Stamp paper   40C1 Date 14-09-2020', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-09-01 05:35:27', 13),
(23, '2020-08-14', 23, 13, 54, 'Photo copy', 3, 10, 1, '', 6, '40C1', 1, '', 'Photo copy 40C1 date 14-8-2020', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-09-01 05:40:09', 18),
(24, '2020-08-17', 24, 13, 54, 'Metre Connection cat', 3, 650, 1, '', 6, '40C1', 1, '', 'Metre Connection cat  40C1 date 17-08-2020', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-09-01 05:46:08', 15),
(25, '2020-08-17', 25, 13, 54, 'Metre letter pad', 3, 60, 1, '', 6, '40C1', 1, '', 'Metre letter pad  40C1 Date 17-08-2020', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-09-01 06:01:30', 15),
(26, '2020-08-22', 26, 14, 56, 'naphthalene ball', 3, 120, 1, '', 2, '41F1', 1, '', 'naphthalene ball 3pkt  41F1 Date 22-08-2020', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-09-01 06:16:30', 10),
(27, '2020-08-22', 27, 14, 56, 'Garbagi bag', 3, 230, 1, '', 7, 'Common', 1, '', 'Garbagi bag  3 pkt Date 22-08-2020', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-09-01 06:22:08', 10),
(28, '2020-08-19', 28, 2, 6, 'Plumber Item Return', 3, -1500, 1, '', 10, '41J1', 1, '', 'Plumber Item Return', '', '', '', '', '', '', '', '', '', '', 2, 2, 'incorrect entry', '2020-09-01 07:56:30', 13),
(29, '2020-09-01', 29, 14, 56, 'Test', 1, 1, 1, '', 10, 'J1G1', 1, '', '', '', '', '', '', '', '', '', '', '', '', 2, 2, 'Test Transaction deleted', '2020-09-01 10:00:50', 0),
(30, '2020-09-01', 30, 14, 56, 'Test2', 1, 1, 1, '', 10, '41J1', 1, '', '', '', '', '', '', '', '', '', '', '', '', 2, 2, 'Test Transaction deleted', '2020-09-01 10:03:22', 0),
(31, '2020-08-19', 31, 2, 6, 'plumber item Retan', 3, 1500, 1, '', 10, '41J1', 1, '', 'plumber item Retan 41J1 Date 19-08-2020', '', '', '', '', '', '', '', '', '', '', 2, 1, '', '2020-09-01 10:44:48', 13),
(32, '2020-09-01', 32, 8, 26, 'Moun Salary  full & Final', 3, 6000, 1, 'CV#1118', 3, '41G1', 1, '', 'Moun Salary  full & Final  Last Warkig day 31-08-2020 All Balance clear', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-09-01 11:00:40', 0),
(33, '2020-09-03', 33, 14, 56, 'Mamta kam wali', 3, 200, 1, 'CV#1119', 2, '41F1', 1, '', 'Mamta kam wali  41F1 2 days warking 200 ', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-09-04 16:55:47', 1),
(34, '2020-09-03', 34, 2, 6, 'Sink Jali', 3, 100, 1, '', 2, '41F1', 1, '', 'Sink Jali  41F1 . 100 ', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-09-04 16:57:51', 1),
(35, '2020-09-03', 35, 11, 42, 'Wagon Petrol', 3, 500, 1, '', 7, 'Common', 1, '', 'Wagon Petrol  500', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-09-04 17:00:06', 1),
(36, '2020-09-04', 36, 6, 22, 'vegitabales', 3, 2350, 1, '', 7, 'Common', 1, '', 'vegitabales  Phase 2 Sabji mandi  2350 Rs Date 04-09-2020', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-09-04 17:06:42', 0),
(37, '2020-09-05', 37, 3, 10, 'Cupboard Lock 4', 3, 320, 1, '', 7, 'Common', 1, '', 'Cupboard Lock 4 ', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-09-05 10:48:18', 0),
(38, '2020-09-05', 38, 3, 9, 'Door Aldrop set', 3, 100, 1, '', 2, '41F1.F3', 1, '', 'Door Aldrop set', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-09-05 10:52:19', 0),
(39, '2020-09-06', 39, 5, 20, 'Grocery', 3, 11451, 1, '', 7, 'Common', 1, '', 'Catogory Quantity Price\r\nArhar Dal 4kg 400\r\nKala Chana 4kg 280\r\nRajmah 4kg 440\r\nUrad Sabut 3kg 270\r\nChana Dal 4kg 280\r\nkali masoor 4kg 300\r\n Lal masoor 4kg 300\r\nmoong Dhuli 2kg 220\r\nUrad chilka 2kg 200\r\nKabuli Chana  4kg 360\r\nMoong Chilka 1kg 100\r\nAtta 50kg 1100\r\nChawal 50kg 2600\r\nRefined 1 tin 1480\r\nSooji 3kg 210\r\nBesan 2kg 180\r\nMaida 1kg 26\r\nTea 1.5kg 300\r\nPoha 4kg 200\r\nVermiceli sevai 5kg 220\r\nRaita boondi 2pkt 140\r\nmacroni 5kg 220\r\nHaldi 500gm 80\r\nDhania powder 1kg 120\r\nDegi mirch 4pkt 120\r\nKitchen king 2pkt 160\r\nsabzi masala 3pkt 120\r\nvim Bar  1pkt 75\r\nnirma 2kg 100\r\nphool jharuh 3pc 180\r\nphenyle 3Bottle 270\r\npohch 3pc 120\r\nachar 2kg 280\r\nTotal  11451\r\nDate-06-09-2020', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-09-06 13:50:59', 0),
(40, '2020-09-06', 40, 14, 56, 'Garbage bag', 3, 120, 1, '', 7, 'Common', 1, '', 'Garbage bag 2 pkt', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-09-07 12:45:25', 1),
(41, '2020-09-04', 41, 14, 56, 'LED Light  Rabbit room', 3, 100, 1, '', 3, '41G1', 1, '', 'LED Light  Rabbit room', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-09-07 12:51:25', 3),
(42, '2020-09-09', 42, 1, 1, 'Fan Capacitor 4 pc 41F1. 2pc  41D1 2pc', 3, 170, 1, '', 7, 'Common', 1, '', ' Fan Capacitor 4 pc 41F1. 2pc  41D1 2pc', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-09-09 10:37:29', 0),
(43, '2020-09-09', 43, 1, 4, 'Switch . 5 & Socket .1', 3, 130, 1, '', 3, '41G1', 1, '', 'Switch . 5 & Socket .1', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-09-09 10:43:03', 0),
(44, '2020-09-10', 44, 6, 22, '5kg Aalu', 3, 180, 1, '', 7, 'Common', 1, '', '5kg Aalu', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-09-10 15:55:08', 0),
(45, '2020-09-10', 45, 13, 54, 'P B C Tap', 3, 20, 1, '', 7, 'Common', 1, '', 'P B C Tap 2', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-09-10 15:58:54', 0),
(46, '2020-09-10', 46, 1, 57, 'Tupelight', 3, 220, 1, '', 5, '41G3.S5', 1, '', 'Tupelight  1 .41G3.S5 ', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-09-10 17:49:28', 0),
(47, '2020-09-12', 47, 6, 22, 'Vegitabales', 3, 3590, 1, '', 7, 'Common', 1, '', 'Vegitabales KG Price\r\nAalu 15 450\r\nTamatar 10 700\r\npyaj 10 350\r\nBhindi 5 200\r\nArbi 5 130\r\nLauki 5 150\r\nKaddu 5 110\r\npatta gobhi 5 180\r\nkarela 3 105\r\nbaingan 3 105\r\nshimla 3 190\r\nbeans 3 200\r\nadrak 1 160\r\nlasan 0.5 80\r\nmirchi 1 70\r\npaneer 1.5 330\r\nmatar 1 80\r\ntotal  3590\r\n', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-09-12 13:16:30', 0),
(48, '2020-09-14', 48, 11, 40, 'Pulsar petrol', 3, 400, 1, '', 7, 'Common', 1, '', 'Pulsar petrol ', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-09-14 12:27:23', 0),
(49, '2020-09-14', 49, 8, 26, 'Jeevan Cook', 3, 2000, 1, 'CV#1120', 3, '41G1', 1, '', 'Jeevan Cook Salary 2000Rs  CV#1120 . Date.14-09-2020', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-09-14 12:35:43', 0),
(50, '2020-09-16', 50, 14, 56, 'Metre connection cut Line man', 3, 200, 1, '', 6, '40C1', 1, '', 'Metre connection cut Line man 200Rs 40C1 date 16 sep 2020', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-09-16 16:59:41', 0),
(51, '2020-09-19', 51, 14, 56, 'RWA Sweeper', 3, 200, 1, '', 2, '41F1', 1, '', 'RWA Sweeper  41F1 ', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-09-19 05:07:38', 0),
(52, '2020-09-20', 52, 5, 52, 'Dosa paste', 3, 150, 1, '', 7, 'Common', 1, '', 'Dosa paste', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-09-20 13:03:18', 0),
(53, '2020-09-21', 53, 2, 6, 'Faucet Jet Spray', 3, 120, 1, '', 3, '41G1G4', 1, '', 'Faucet Jet Spray', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-09-21 14:08:26', 0),
(54, '2020-09-21', 54, 11, 39, 'CT 100 Bike Petrol', 3, 300, 1, '', 7, 'Common', 1, '', 'CT 100 Bike Petrol', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-09-21 14:11:33', 0),
(55, '2020-09-21', 55, 6, 22, '2Kg Aalu', 3, 70, 1, '', 5, '41G3', 1, '', '2Kg Aalu', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-09-21 14:13:25', 0),
(56, '2020-09-23', 56, 4, 11, '9999098840', 2, 500, 1, '', 7, 'Common', 1, '', '9999098840 Mob. Number Recharge 500/-', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-09-23 17:51:27', 0),
(57, '2020-09-23', 57, 4, 11, '9999098810', 2, 1000, 1, '', 7, 'Common', 1, '', '9999098810 Mob. Recharge 1000/-', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-09-23 17:53:22', 0),
(58, '2020-09-23', 58, 4, 11, '9999098842 Prepaid number', 2, 1499, 1, '', 7, 'Common', 1, '', '9999098842 1 Year Recharge 1499/-', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-09-23 17:55:30', 0),
(59, '2020-09-24', 59, 6, 22, 'Vegetables', 2, 3335, 1, '', 7, 'Common', 1, '', 'Vegetables ', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-09-24 09:48:36', 0),
(60, '2020-09-24', 60, 1, 5, '2 Geyser Fiting, 4 Swith Board Fix, Inverter Wair Remove , Sheet fix on Mcb Box', 2, 1200, 1, 'CV#1121', 10, '41J1', 1, '', '2 Geyser Fiting, 4 Swith Board Fix, Inverter Wair Remove , Sheet fix on Mcb Box', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-09-24 15:27:38', 0),
(61, '2020-09-26', 61, 11, 39, 'CT 100 Petrol 300/-', 2, 300, 1, '', 7, 'Common', 1, '', 'CT 100 petrol 300/-', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-09-26 14:42:22', 0),
(62, '2020-09-26', 62, 8, 27, 'Amar reference  500', 3, 500, 1, 'Cv#1122', 3, '41G1', 1, '', 'Amar Singh 500 CV#1122', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-09-26 14:46:18', 0),
(63, '2020-09-26', 63, 1, 57, 'Tube light purchase sai electrical Barola\r\n220/-', 2, 220, 1, '', 1, 'Common', 1, '', 'Tube light purchase sai electrical Barola\r\n220/-', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-09-26 14:49:29', 0),
(64, '2020-09-26', 64, 1, 57, 'Tube light 20 watt purchase from Barola Sai electrical', 2, 250, 1, '', 1, 'Common', 1, '', 'Tube light 20 watt purchase from Barola Sai electrical', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-09-26 14:51:48', 0),
(65, '2020-09-26', 65, 4, 11, 'Landline Bill pay 450/- 01204348800', 2, 450, 1, '', 2, 'Common', 1, '', 'Landline Bill pay 450/- 01204348800', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-09-27 05:29:52', 1),
(66, '2020-09-25', 66, 5, 20, '20 Kg Flour', 2, 500, 1, '', 7, 'Common', 1, '', '20 Kg Flour', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-09-27 05:34:05', 2),
(67, '2020-09-27', 67, 5, 52, '4 Kg Idli Paste', 2, 200, 1, '', 7, 'Common', 1, '', '4 Kg Idli Paste', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-09-27 05:35:57', 0),
(68, '2020-09-26', 68, 9, 29, '500 Ml Milk for Nikita pick luggage', 2, 24, 1, '', 2, 'Common', 1, '', '500 Ml Milk tea  for Nikita pick luggage ', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-09-27 14:52:26', 1),
(69, '2020-09-27', 69, 9, 29, '500 Ml Milk tea for New Customer', 2, 24, 1, '', 2, '41F1-G3', 1, '', '500 Ml Milk tea for New Customer ', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-09-27 14:54:32', 0),
(70, '2020-09-28', 70, 11, 42, 'Wagon R Petrol 390/-', 2, 390, 1, '', 7, 'Common', 1, '', 'Wagon R Petrol 390/-', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-09-28 10:28:00', 0),
(71, '2020-09-28', 71, 1, 0, 'Board 6A 2*2 from Sai Electricals Barola Mob. No. 9910837988', 2, 180, 1, '', 2, '41F1-G1', 1, '', 'Board 6A 2*2 from Sai Electricals Barola Mob. No. 9910837988', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-09-28 10:32:11', 0),
(72, '2020-09-28', 72, 1, 0, '1 Wair Gitty Pkt  from Sai Electricals Barola Mob. No. 9910837988', 2, 20, 1, '', 2, '41F1-G1', 1, '', '1 Wair Gitty Pkt  from Sai Electricals Barola Mob. No. 9910837988', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-09-28 10:33:57', 0),
(73, '2020-09-28', 73, 1, 0, 'Wair Striper 50/-', 2, 50, 1, '', 2, 'Common', 1, '', 'Wair Striper 50/-', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-09-28 10:51:49', 0),
(74, '2020-09-29', 74, 9, 29, 'Butter for Dal Makhni 2 Pc 20/-', 2, 20, 1, '', 5, 'Common', 1, '', 'Butter for Dal Makhni 2 Pc 20/-', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-09-29 13:32:37', 0),
(75, '2020-09-29', 75, 1, 1, 'Capister 50/-', 2, 50, 1, '', 1, '41D1-G3', 1, '', 'Capister 50/-', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-09-29 13:33:59', 0),
(76, '2020-09-29', 76, 5, 20, 'Rajma 500 Gm 60/-', 2, 60, 1, '', 5, 'Common', 1, '', 'Rajma 500 Gm 60/-', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-09-29 13:34:59', 0),
(77, '2020-10-01', 77, 9, 29, '500 Ml cow milk', 2, 24, 1, '', 2, 'Common', 1, '', '500 Ml cow milk', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-10-01 16:05:57', 0),
(78, '2020-10-02', 78, 6, 22, 'vegetables Purchase from noida phase 2   5170/-', 2, 5170, 1, '', 7, 'Common', 1, '', 'vegetables Purchase from noida phase 2   5170/-', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-10-02 08:44:08', 0),
(79, '2020-10-02', 79, 14, 56, 'charger Purchase for Mohit Sir 250/-', 2, 250, 1, '', 7, 'Common', 1, '', 'charger Purchase for Mohit Sir 250/-', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-10-02 08:47:36', 0),
(80, '2020-10-30', 80, 5, 0, 'Grocery Purchase 5500/-', 2, 5500, 1, '', 7, 'Common', 1, '', 'Grocery Purchase 5500/-', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-10-02 08:50:00', 28),
(81, '2020-10-03', 81, 1, 0, 'wair Gitti Big Pkt  30/-', 2, 30, 1, '', 2, '41F1-G2', 1, '', 'wair Gitti Big Pkt  30/-', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-10-04 13:44:53', 1),
(82, '2020-10-04', 82, 5, 52, '2 kg Idli Paste 100/-', 2, 100, 1, '', 2, 'Common', 1, '', '2 kg Idli Paste 100/-', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-10-04 13:46:42', 0),
(83, '2020-10-04', 83, 5, 20, '4 Kg namak 72/-  15 Kg chini 570/-', 2, 642, 1, '', 7, 'Common', 1, '', '4 Kg namak 72/-  15 Kg chini 570/-', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-10-04 13:48:51', 0),
(84, '2020-10-04', 84, 3, 10, 'Almirah Handle 180/- Grover Hardware Barol Mob.- 9810687514', 2, 180, 1, '', 5, '41G3-G2', 1, '', 'Almirah Handle 180/- Grover Hardware Barol Mob.- 9810687514', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-10-04 13:51:40', 0),
(85, '2020-10-05', 85, 11, 39, 'Ct 100 Petrol 300/-', 2, 300, 1, '', 7, 'Common', 1, '', 'Ct 100 Petrol 300/-', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-10-05 16:54:07', 0),
(86, '2020-10-06', 86, 14, 56, 'Bans 6 Pc 115Rs/Pc', 2, 690, 1, '', 1, 'Common', 1, '', 'Bans 6 Pc 115Rs/Pc', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-10-06 05:42:21', 0),
(87, '2020-10-06', 87, 14, 56, 'Rassi for Bans 100/-', 2, 100, 1, '', 1, 'Common', 1, '', 'Rassi for Bans 100/-', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-10-06 05:43:31', 0),
(88, '2020-10-06', 88, 14, 56, 'Bans Rikshaw Fair 100/-', 2, 100, 1, '', 1, 'Common', 1, '', 'Bans Rikshaw Fair 100/-', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-10-06 05:44:47', 0),
(89, '2020-10-06', 89, 14, 56, 'Lock 2 pc', 3, 110, 1, '', 2, '41F1', 1, '', 'Lock 2 pc', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-10-07 11:43:05', 1),
(90, '2020-10-07', 90, 14, 56, 'Pressure Cooker Repair 100/- from Kajal kitchen center Mob. No. 9811824092', 2, 100, 1, 'CV#1123', 2, 'Common', 1, '', 'Pressure Cooker Repair 100/- from Kajal kitchen center Mob. No. 9811824092 ', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-10-08 17:09:03', 1),
(91, '2020-10-08', 91, 5, 20, 'Grocery Purchase From Barola 3365/-', 2, 3365, 1, '', 7, 'Common', 1, '', 'Grocery Purchase From Barola 3365/-', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-10-08 17:21:51', 0),
(92, '2020-10-14', 92, 14, 56, 'staff tv Recharge  41F1F3 272Rs', 3, 272, 1, '', 2, '41F1.F3', 1, '', 'staff tv Recharge  41F1F3 272Rs ', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-10-14 12:48:07', 0),
(93, '2020-10-09', 93, 11, 41, 'Eeco Petral', 2, 500, 1, '', 7, 'Common', 1, '', 'Eeco Petral ', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-10-14 13:15:47', 5),
(94, '2020-10-09', 94, 11, 43, 'Eeco CNG', 2, 375, 1, '', 7, 'Common', 1, '', 'Eeco CNG', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-10-14 13:18:18', 5),
(95, '2020-10-09', 95, 14, 56, '9 Bed sifting &26side tabal', 2, 2740, 1, 'CV#1124', 3, '41G1', 1, '', '9 Bed sifting &26side tabal', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-10-14 13:23:09', 5),
(96, '2020-10-09', 96, 14, 56, '1 Gas cylinder', 2, 600, 1, '', 7, 'Common', 1, '', '1 Gas cylinder ', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-10-14 13:26:12', 5),
(97, '2020-10-10', 97, 14, 56, '9 Bed Shifing  Riksha', 2, 910, 1, '', 3, 'Common', 1, '', '9 Bed Shifing  Riksha', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-10-14 13:35:30', 4),
(98, '2020-10-10', 98, 11, 37, 'Eeco tyre repair 2', 2, 300, 1, '', 7, 'Common', 1, '', 'Eeco tyre repair 2', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-10-14 13:39:16', 4),
(99, '2020-10-11', 99, 5, 52, 'Idli paste 3kg', 2, 150, 1, '', 7, 'Common', 1, '', 'Idli paste 3kg', '', '', '', '', '', '', '', '', '', '', 1, 2, 'Duplicate entry', '2020-10-14 13:45:19', 3),
(100, '2020-10-11', 100, 5, 52, 'Idli paste 3kg', 2, 150, 1, '', 7, 'Common', 1, '', 'Idli paste 3kg', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-10-14 13:45:19', 3),
(101, '2020-10-11', 101, 8, 26, '1days Salary  Sarvesh kumar', 2, 266, 1, 'CV#1125', 2, '41F1', 1, '', '1days Salary  Sarvesh kumar', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-10-14 13:49:04', 3),
(102, '2020-10-12', 102, 14, 56, 'Halder 1 pc', 2, 20, 1, '', 2, '41F1', 1, '', 'Halder 1 pc', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-10-14 13:51:53', 2),
(103, '2020-10-12', 103, 14, 56, '3Mtr pipe', 2, 21, 1, '', 7, 'Common', 1, '', '3Mtr pipe ', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-10-14 13:54:22', 2),
(104, '2020-10-12', 104, 14, 56, '1 tokri', 2, 40, 1, '', 7, 'Common', 1, '', '1 tokri ', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-10-14 13:55:41', 2),
(105, '2020-10-12', 105, 5, 20, 'grocery', 2, 2440, 1, '', 7, 'Common', 1, '', '1 tin .1500                                                                                                                                                                                                                                                                          5Tomato sauce .450                                                                                                                                                                                                                                2pkt scotch pad .170                                                                                                                                                                                                                                             250gm ajwain.70                                                                                                                                                                                                                       5kg namak .90                                                                                                                                                                                                                                           2kg safed matar .160', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-10-14 14:05:09', 2),
(106, '2020-10-13', 106, 6, 22, 'vegetables', 2, 3205, 1, '', 7, 'Common', 1, '', 'vegetables', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-10-14 14:06:49', 1),
(107, '2020-10-14', 107, 14, 56, '2 Rassi rent', 2, 150, 1, '', 1, '41D1', 1, '', '2 Rassi rent', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-10-14 14:10:12', 0),
(108, '2020-10-15', 108, 14, 56, 'Medicine navistar 5mg 1 patta   mohit sir', 3, 162, 1, '', 1, '41D1', 1, '', 'Medicine navistar 5mg 1 patta   mohit sir ', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-10-15 13:13:11', 0),
(109, '2020-10-15', 109, 14, 56, 'Medicine T.sart H 40mg 1patta  mohit sir', 3, 228, 1, '', 1, '41D1', 1, '', 'Medicine T.sart H 40mg 1patta  mohit sir ', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-10-15 13:17:27', 0),
(110, '2020-10-16', 110, 14, 56, 'Serew Driver sat ( Taparia)', 3, 220, 1, '', 7, 'Common', 1, '', 'Serew Driver sat ( Taparia)', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-10-20 09:41:43', 4),
(111, '2020-10-16', 111, 14, 56, 'Drill bit', 3, 30, 1, '', 7, 'Common', 1, '', 'Drill bit', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-10-20 09:45:45', 4),
(112, '2020-10-17', 112, 14, 56, 'Ludo', 3, 230, 1, '', 7, 'Common', 1, '', 'Ludo ', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-10-20 09:48:13', 3),
(113, '2020-10-17', 113, 11, 42, 'Wagonr Petrol', 3, 300, 1, '', 7, 'Common', 1, '', 'Wagonr Petrol', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-10-20 09:51:56', 3),
(114, '2020-10-17', 114, 11, 37, 'Eeco Service', 3, 1890, 1, '', 7, 'Common', 1, '', 'Eeco Service', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-10-20 09:54:37', 3),
(115, '2020-10-17', 115, 5, 20, 'Grocery', 3, 3240, 1, '', 7, 'Common', 1, '', 'Grocery', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-10-20 10:03:11', 3),
(116, '2020-10-18', 116, 14, 56, '3kg Noodles', 3, 220, 1, '', 7, 'Common', 1, '', '3kg noodles', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-10-20 10:20:11', 2),
(117, '2020-10-18', 117, 6, 22, 'Patta Gobi 1.5kg', 3, 100, 1, '', 7, 'Common', 1, '', 'Patta Gobi 1.5kg ', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-10-20 10:23:02', 2),
(118, '2020-10-18', 118, 6, 22, 'Semla mirch 500gm', 3, 80, 1, '', 7, 'Common', 1, '', 'Semla mirch 500gm', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-10-20 10:25:11', 2),
(119, '2020-10-18', 119, 14, 56, 'Welding D157 for shaft 200Rs', 2, 200, 1, '', 1, '41D1', 1, '', 'Welding D157 for shaft 200Rs ', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-10-20 10:48:10', 2),
(120, '2020-10-19', 120, 14, 56, 'Grinder machine gitti', 2, 125, 1, '', 1, '41D1', 1, '', 'Grinder machine gitti', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-10-20 10:51:34', 1),
(121, '2020-10-22', 121, 14, 56, 'Irfan Welder 41D1  10000 Cash CV#1126', 3, 10000, 1, 'CV#11226', 1, '41D1', 1, '', 'Irfan Welder 41D1  10000 Cash CV#1126', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-10-31 15:46:44', 9),
(122, '2020-10-23', 122, 8, 26, 'Jeevan Salary 2000CV#1128', 3, 2000, 1, '', 3, '41G1', 1, '', 'Jeevan Salary 2000CV#1128', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-11-05 11:00:39', 13),
(123, '2020-11-06', 123, 11, 42, 'wagon R petrol 400RS', 3, 400, 1, '', 7, 'Common', 1, '', 'wagon R petrol 400RS ', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-11-06 11:00:34', 0),
(124, '2020-11-05', 124, 14, 56, '9999098810 Recharge 213', 3, 213, 1, '', 7, 'Common', 1, '', '9999098810 Recharge 213', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-11-11 06:42:19', 6),
(125, '2020-11-05', 125, 5, 20, '10kg Atta', 3, 240, 1, '', 7, 'Common', 1, '', '10kg Atta', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-11-11 06:43:57', 6),
(126, '2020-11-05', 126, 5, 20, '250gm Tea', 3, 70, 1, '', 5, '41G3', 1, '', '250gm Tea', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-11-11 06:45:49', 6),
(127, '2020-11-07', 127, 14, 56, 'Coold Dringk  200ml 4.  60Rs', 3, 60, 1, '', 5, '41G3', 1, '', 'Coold Dringk  200ml 4.  60Rs', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-11-11 06:52:11', 4),
(128, '2020-11-07', 128, 14, 56, 'Good day Biskit 20', 3, 20, 1, '', 5, '41G3', 1, '', 'Good day Biskit 20', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-11-11 06:54:08', 4),
(129, '2020-11-07', 129, 14, 56, 'Lays Chips 20', 3, 20, 1, '', 5, '41G3', 1, '', 'Lays Chips 20', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-11-11 06:55:22', 4),
(130, '2020-11-07', 130, 14, 56, 'ilayachi 1 pkt 10', 3, 10, 1, '', 5, '41G3', 1, '', 'ilayachi 1 pkt 10', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-11-11 06:56:38', 4),
(131, '2020-11-07', 131, 14, 56, 'Disposal Galass 4 pc 20', 3, 20, 1, '', 5, '41G3', 1, '', 'Disposal Galass 4 pc 20', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-11-11 06:58:09', 4),
(132, '2020-11-07', 132, 14, 56, '1pkt Milk 28', 3, 28, 1, '', 5, '41G3', 1, '', '1pkt Milk 28', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-11-11 06:59:23', 4),
(133, '2020-11-07', 133, 14, 56, 'Sweeper 41G1 200', 3, 200, 1, '', 3, '41G1', 1, '', 'Sweeper 41G1 200', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-11-11 07:03:08', 4),
(134, '2020-11-10', 134, 6, 22, 'Vagitabals  4280', 3, 4280, 1, '', 7, 'Common', 1, '', 'Vagitabals  4280', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-11-11 07:04:47', 1),
(135, '2020-11-10', 135, 11, 43, 'Eeco CNG 290', 3, 290, 1, '', 7, 'Common', 1, '', 'Eeco CNG 290', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-11-11 07:07:02', 1),
(136, '2020-11-10', 136, 8, 26, 'Sarvesh salary 8000 CV#1136', 3, 8000, 1, 'CV#1136', 2, '41F1', 1, '', 'Sarvesh salary 8000 CV#1136', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-11-11 07:11:41', 1),
(137, '2020-11-10', 137, 8, 26, 'Jeevan Salary 2000 CV#1137', 3, 2000, 1, 'CV#1137', 3, '41G1', 1, '', 'Jeevan Salary 2000 CV#1137', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-11-11 07:14:44', 1),
(138, '2020-11-10', 138, 14, 56, 'Photo copy 20', 3, 20, 1, '', 1, '41D1', 1, '', 'Photo copy 20', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-11-11 07:17:00', 1),
(139, '2020-11-12', 139, 14, 56, 'Diya 45 Diwali ke liye', 3, 70, 1, '', 7, 'Common', 1, '', 'Diya 45 Diwali ke liye ', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-12-21 07:12:05', 39),
(140, '2020-11-12', 140, 14, 56, 'Cotton 3 pkt', 3, 30, 1, '', 7, 'Common', 1, '', 'Cotton 3 pkt', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-12-21 07:13:43', 39),
(141, '2020-11-12', 141, 14, 56, 'Til ka oil 3 bottal', 3, 210, 1, '', 7, 'Common', 1, '', 'Til ka oil 3 bottal', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-12-21 07:15:11', 39),
(142, '2020-11-18', 142, 14, 56, 'Tirpal', 3, 2900, 1, '', 1, '41D1', 1, '', 'Tirpal', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-12-21 07:17:12', 33),
(143, '2020-12-18', 143, 14, 56, 'Walcrw', 3, 240, 1, '', 1, '41D1', 1, '', 'Walcrw ', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-12-21 07:19:05', 3),
(144, '2020-11-18', 144, 14, 56, 'LOOPi', 3, 290, 1, '', 1, '41D1', 1, '', 'LOOPi', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-12-21 07:20:17', 33),
(145, '2020-11-18', 145, 14, 56, 'Azad market to noida uber', 3, 350, 1, '', 7, 'Common', 1, '', 'Azad market to noida uber', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-12-21 07:22:43', 33),
(146, '2020-11-18', 146, 14, 56, 'Tailor', 3, 500, 1, '', 1, '41D1', 1, '', 'Tailor', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-12-21 07:24:09', 33),
(147, '2020-11-18', 147, 14, 56, 'Lunch', 3, 150, 1, '', 7, 'Common', 1, '', 'Lunch', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-12-21 07:25:21', 33),
(148, '2020-11-20', 148, 14, 56, 'fastener 10 pc', 3, 150, 1, '', 1, '41D1', 1, '', 'fastener 10 pc', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-12-21 07:28:09', 31),
(149, '2020-11-20', 149, 14, 56, 'Drill machine bit', 3, 70, 1, '', 1, '41D1', 1, '', 'Drill machine bit', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-12-21 07:31:21', 31),
(150, '2020-12-04', 150, 9, 29, 'Cow milk 1 500ml', 3, 24, 1, '', 1, '41D1', 1, '', 'Cow milk 1 500ml', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-12-21 07:36:27', 17),
(151, '2020-12-04', 151, 9, 29, 'Tonde  milk 1 500ml', 3, 23, 1, '', 1, '41D1', 1, '', 'Tonde  milk 1 500ml', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-12-21 07:38:17', 17),
(152, '2020-12-05', 152, 9, 28, 'mother Dairy advanec 4000  Date 05-dec-20', 3, 4000, 1, '', 7, 'Common', 1, '', 'mother Dairy advanec 4000  Date 05-dec-20\r\n', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-12-21 13:05:52', 16),
(153, '2020-12-05', 153, 9, 29, 'Tonde 500ml', 3, 23, 1, '', 1, '41D1', 1, '', 'Tonde 500ml', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-12-21 13:07:19', 16),
(154, '2020-12-05', 154, 9, 29, 'cow milk 500ml', 3, 24, 1, '', 1, '41D1', 1, '', 'cow milk 500ml', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-12-21 13:08:54', 16),
(155, '2020-12-05', 155, 14, 56, 'PVC Pipe  cap 1pc', 3, 90, 1, '', 1, '41D1', 1, '', 'PVC Pipe  cap 1pc', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-12-21 13:10:45', 16),
(156, '2020-12-05', 156, 14, 56, 'M Seal 1pkt', 3, 60, 1, '', 1, '41D1', 1, '', 'M Seal 1pkt', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-12-21 13:12:46', 16),
(157, '2020-12-06', 157, 9, 29, 'Tonde 500ml', 3, 23, 1, '', 1, '41D1', 1, '', 'Tonde 500ml', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-12-21 13:22:44', 15),
(158, '2020-12-06', 158, 9, 29, 'Cow milk 500ml', 3, 24, 1, '', 1, '41D1', 1, '', 'Cow milk 500ml', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-12-21 13:24:15', 15),
(159, '2020-12-06', 159, 9, 32, 'Bread 1pkt', 3, 40, 1, '', 2, '41F1', 1, '', 'Bread 1pkt', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-12-21 13:26:05', 15),
(160, '2020-12-06', 160, 5, 52, '2kg  noodles', 3, 150, 1, '', 5, '41G3', 1, '', '2kg  noodles', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-12-21 13:28:06', 15),
(161, '2020-12-06', 161, 14, 56, '2Cpboard 6000 Recd Arun by 9634727419 Date 06-dec-20', 3, 6000, 1, '', 6, '40C1', 1, '', '2Cpboard 6000 Recd Arun by 9634727419 Date 06-dec-20', '', '', '', '', '', '', '', '', '', '', 2, 1, '', '2020-12-21 13:34:53', 15),
(162, '2020-12-07', 162, 9, 28, 'Rajendar mather dairy pament 2637 CV#1139 date 07-12-20', 3, 2637, 1, 'CV#1139', 7, 'Common', 1, '', 'Rajendar mather dairy pament 2637 CV#1139 date 07-12-20', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-12-21 13:54:40', 14),
(163, '2020-12-07', 163, 5, 20, 'Gas cylinder', 3, 850, 1, '', 1, '41D1', 1, '', 'Gas cylinder', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-12-21 13:57:46', 14),
(164, '2020-12-07', 164, 9, 29, 'Tonde 1ltr', 3, 47, 1, '', 1, '41D1', 1, '', 'Tonde 1ltr', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-12-21 13:59:37', 14),
(165, '2020-12-07', 165, 9, 29, 'Cow milk 500ml', 3, 24, 1, '', 1, '41D1', 1, '', 'Cow milk 500ml', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-12-21 14:01:19', 14),
(166, '2020-12-07', 166, 11, 41, 'Eeco petrol', 3, 300, 1, '', 7, 'Common', 1, '', 'Eeco petrol', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-12-21 14:03:36', 14),
(167, '2020-12-07', 167, 5, 20, 'Teapatti', 3, 150, 1, '', 7, 'Common', 1, '', 'Teapatti', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-12-21 14:05:26', 14),
(168, '2020-12-07', 168, 14, 56, '1 Copbard or 1 bed 3000 by Jatindar 8218924491', 3, 3000, 1, '', 6, '40C1', 1, '', '1 Copbard or 1 bed 3000 by Jatindar 8218924491', '', '', '', '', '', '', '', '', '', '', 2, 1, '', '2020-12-21 14:13:07', 14),
(169, '2020-12-08', 169, 14, 56, 'AC Sfting 40c1 to 41D1', 3, 500, 1, '', 1, '41D1', 1, '', 'AC Sfting 40c1 to 41D1', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-12-21 14:16:26', 13),
(170, '2020-12-08', 170, 5, 20, '20kg Atta', 3, 500, 1, '', 7, 'Common', 1, '', '20kg Atta\r\n  ', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-12-21 14:18:43', 13),
(171, '2020-12-13', 171, 14, 56, '1 Bed Ravindar 1000', 3, 1000, 1, '', 6, '40C1', 1, '', '1 Bed Ravindar 1000', '', '', '', '', '', '', '', '', '', '', 2, 1, '', '2020-12-21 14:23:35', 8),
(172, '2020-12-19', 172, 14, 56, 'Rope Light', 3, 5096, 1, '', 1, '41D1', 1, '', 'Rope Light ', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-12-22 11:24:17', 3),
(173, '2020-12-19', 173, 14, 56, 'Rope Light', 3, 5096, 1, '', 1, '41D1', 1, '', 'Rope Light ', '', '', '', '', '', '', '', '', '', '', 1, 1, '', '2020-12-22 11:24:17', 3);

-- --------------------------------------------------------

--
-- Table structure for table `expense_category`
--

CREATE TABLE `expense_category` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `expense_category`
--

INSERT INTO `expense_category` (`id`, `name`, `status`) VALUES
(1, 'Maintenance - Electrical', 1),
(2, 'Maintenance - Plumber', 1),
(3, 'Maintenance - Carpenter', 1),
(4, 'Monthly Recurring Expense', 1),
(5, 'Grocery', 1),
(6, 'Vegetables', 1),
(7, 'Building Expenses', 1),
(8, 'Staff', 1),
(9, 'Mother Dairy', 1),
(10, 'Fixed Assets Purchase', 1),
(11, 'Vehicle', 1),
(12, 'Infrastructure and Setup Expenses', 1),
(13, 'Stationary and Advertisement', 1),
(14, 'Miscellaneous', 1);

-- --------------------------------------------------------

--
-- Table structure for table `expense_subcategory`
--

CREATE TABLE `expense_subcategory` (
  `id` int(11) NOT NULL,
  `exp_category_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `expense_subcategory`
--

INSERT INTO `expense_subcategory` (`id`, `exp_category_id`, `name`, `status`) VALUES
(1, 1, 'Fan', 1),
(2, 1, 'LED TV', 1),
(3, 1, 'AC', 1),
(4, 1, 'RO', 1),
(5, 1, 'Geyser', 1),
(6, 2, 'Tap', 1),
(7, 2, 'Naali Block', 1),
(8, 2, 'Water Tank', 1),
(9, 3, 'Door', 1),
(10, 3, 'Almirah', 1),
(11, 4, 'Mobile Bill', 1),
(12, 4, 'Broadband', 1),
(13, 4, 'Cable', 1),
(14, 4, 'Sweeper', 1),
(15, 4, 'RWA', 1),
(16, 4, 'Pipeline Gas', 1),
(18, 4, 'Electricity Bill', 1),
(19, 4, 'Cylinder', 1),
(20, 5, 'Grocery', 1),
(21, 5, 'Pulses', 1),
(22, 6, 'Vegetables', 1),
(23, 7, 'Rent', 1),
(24, 7, 'Maintenance on Landlord Behalf', 1),
(25, 7, 'Water Bill', 1),
(26, 8, 'Salary', 1),
(27, 8, 'Incentive', 1),
(28, 9, 'Monthly Bill', 1),
(29, 9, 'Milk', 1),
(30, 9, 'Curd', 1),
(31, 9, 'Chhanchh', 1),
(32, 9, 'Bread', 1),
(33, 10, 'AC', 1),
(34, 10, 'LED TV', 1),
(35, 11, 'CT 100 Maintenance', 1),
(36, 11, 'Pulsar Maintenance', 1),
(37, 11, 'Eeco Maintenance', 1),
(38, 11, 'Wagon R Maintenance', 1),
(39, 11, 'CT 100 Petrol', 1),
(40, 11, 'Pulsar Petrol', 1),
(41, 11, 'Eeco Petrol', 1),
(42, 11, 'Wagon R Petrol', 1),
(43, 11, 'Eeco CNG', 1),
(44, 12, 'Plyboard', 1),
(45, 12, 'Electrical', 1),
(46, 12, 'Carpenter', 1),
(47, 12, 'Plumber', 1),
(48, 12, 'Material', 1),
(49, 1, 'Refrigerator', 1),
(50, 1, 'Microwave', 1),
(51, 1, 'Inverter', 1),
(52, 5, 'Idli Dosa Paste', 1),
(53, 13, 'Printing', 1),
(54, 13, 'Stationary', 1),
(55, 13, 'Portal Package', 1),
(56, 14, 'Miscellaneous', 1),
(57, 1, 'Tubelight', 1),
(58, 1, 'LED Bulb', 1);

-- --------------------------------------------------------

--
-- Table structure for table `income_register`
--

CREATE TABLE `income_register` (
  `register_id` int(11) NOT NULL,
  `transaction_id` int(11) NOT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `employee_id` int(11) NOT NULL,
  `other_emp_id` int(11) DEFAULT NULL,
  `income` int(11) DEFAULT NULL,
  `expense` int(11) DEFAULT NULL,
  `mode` int(11) NOT NULL,
  `other_mode` int(11) NOT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `payment_status` int(11) DEFAULT NULL,
  `source` varchar(255) NOT NULL,
  `createdat` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `income_register`
--

INSERT INTO `income_register` (`register_id`, `transaction_id`, `customer_id`, `employee_id`, `other_emp_id`, `income`, `expense`, `mode`, `other_mode`, `comment`, `payment_status`, `source`, `createdat`) VALUES
(4, 3, NULL, 2, 3, NULL, 3000, 1, 1, '  Yogesh to Arun Cash Handover Rs3000 dt 5Aug2020', NULL, 'E', '2020-08-29 15:43:55'),
(5, 3, NULL, 3, 2, 3000, NULL, 1, 1, '  Yogesh to Arun Cash Handover Rs3000 dt 5Aug2020', NULL, 'E', '2020-08-29 15:43:55'),
(6, 1, 14, 3, NULL, 10000, 0, 1, 0, NULL, NULL, 'Rev', '2020-08-29 15:48:16'),
(7, 2, 38, 3, NULL, 0, 878, 1, 0, NULL, NULL, 'Rev', '2020-08-29 15:59:40'),
(8, 3, 39, 3, NULL, 4000, 0, 1, 0, NULL, NULL, 'Rev', '2020-08-29 16:12:47'),
(9, 4, 6, 3, NULL, 2000, 0, 1, 0, NULL, NULL, 'Rev', '2020-08-29 16:17:40'),
(10, 5, 8, 3, NULL, 1000, 0, 1, 0, NULL, NULL, 'Rev', '2020-08-29 16:21:14'),
(12, 2, NULL, 3, NULL, 0, 2420, 1, 0, 'Face 2 mandi', NULL, 'Exp', '2020-08-29 17:02:27'),
(13, 3, NULL, 3, NULL, 0, 100, 1, 0, 'Idli paste 2 kg', NULL, 'Exp', '2020-08-29 17:23:41'),
(14, 4, NULL, 3, NULL, 0, 300, 1, 0, 'Pulsar petrol', NULL, 'Exp', '2020-08-30 05:17:53'),
(15, 5, NULL, 3, NULL, 0, 1000, 1, 0, 'plumber item', NULL, 'Exp', '2020-08-30 05:36:25'),
(16, 6, NULL, 3, NULL, 0, 1750, 1, 0, 'Pulsar bike maintenance', NULL, 'Exp', '2020-08-30 05:49:56'),
(17, 7, NULL, 3, NULL, 0, 400, 1, 0, 'Pulsar petrol', NULL, 'Exp', '2020-08-30 05:59:02'),
(18, 8, NULL, 3, NULL, 0, 280, 1, 0, 'Atta 5kg  41D1 ', NULL, 'Exp', '2020-08-30 15:41:33'),
(19, 9, NULL, 3, NULL, 0, 40, 1, 0, 'Breed 1pkt 41D1', NULL, 'Exp', '2020-08-30 15:45:19'),
(20, 10, NULL, 3, NULL, 0, 60, 1, 0, 'Rajma 500gm 41G3', NULL, 'Exp', '2020-08-30 15:50:20'),
(23, 13, NULL, 3, NULL, 0, 1500, 1, 0, 'Ravinder plumber  CV#1116 1500Rs', NULL, 'Exp', '2020-08-30 16:26:13'),
(24, 7, 42, 3, NULL, 0, 500, 1, 0, NULL, NULL, 'Rev', '2020-08-31 07:20:20'),
(25, 14, NULL, 3, NULL, 0, 1590, 1, 0, 'Vegetables Phase 2 sabzi mandi    1590Rs', NULL, 'Exp', '2020-08-31 07:31:15'),
(26, 15, NULL, 3, NULL, 0, 200, 1, 0, 'Pulsar petrol  19-08-2020  . 200Rs', NULL, 'Exp', '2020-08-31 07:36:10'),
(27, 16, NULL, 3, NULL, 0, 140, 1, 0, 'noodles 2 kg 22-08-2020', NULL, 'Exp', '2020-08-31 07:39:35'),
(28, 17, NULL, 3, NULL, 0, 2500, 1, 0, 'Ravinder plumber  All due clear   2500Rs  CV#1117 Date 24-08-2020', NULL, 'Exp', '2020-08-31 07:46:59'),
(29, 18, NULL, 3, NULL, 0, 2660, 1, 0, 'vegetables sabzi mandi phase 2', NULL, 'Exp', '2020-08-31 08:01:51'),
(30, 19, NULL, 3, NULL, 0, 150, 1, 0, 'Dosa paste 3 kg', NULL, 'Exp', '2020-08-31 08:05:45'),
(31, 20, NULL, 3, NULL, 0, 100, 1, 0, 'Sweeper 41F1 nali clean', NULL, 'Exp', '2020-08-31 08:13:19'),
(32, 8, 2, 3, NULL, 10000, 0, 1, 0, NULL, NULL, 'Rev', '2020-08-31 16:00:13'),
(34, 21, NULL, 3, NULL, 0, 730, 1, 0, 'Cald Drank  41D1 ', NULL, 'Exp', '2020-09-01 05:23:15'),
(35, 22, NULL, 3, NULL, 0, 100, 1, 0, 'Stamp paper   40C1 Date 14-09-2020', NULL, 'Exp', '2020-09-01 05:35:27'),
(36, 23, NULL, 3, NULL, 0, 10, 1, 0, 'Photo copy 40C1 date 14-8-2020', NULL, 'Exp', '2020-09-01 05:40:09'),
(37, 24, NULL, 3, NULL, 0, 650, 1, 0, 'Metre Connection cat  40C1 date 17-08-2020', NULL, 'Exp', '2020-09-01 05:46:08'),
(38, 25, NULL, 3, NULL, 0, 60, 1, 0, 'Metre letter pad  40C1 Date 17-08-2020', NULL, 'Exp', '2020-09-01 06:01:30'),
(39, 26, NULL, 3, NULL, 0, 120, 1, 0, 'naphthalene ball 3pkt  41F1 Date 22-08-2020', NULL, 'Exp', '2020-09-01 06:16:30'),
(40, 27, NULL, 3, NULL, 0, 230, 1, 0, 'Garbagi bag  3 pkt Date 22-08-2020', NULL, 'Exp', '2020-09-01 06:22:08'),
(44, 31, NULL, 3, NULL, 1500, 0, 1, 0, 'plumber item Retan 41J1 Date 19-08-2020', NULL, 'Exp', '2020-09-01 10:44:48'),
(45, 32, NULL, 3, NULL, 0, 6000, 1, 0, 'Moun Salary  full & Final  Last Warkig day 31-08-2020 All Balance clear', NULL, 'Exp', '2020-09-01 11:00:40'),
(46, 10, 41, 3, NULL, 0, 88, 1, 0, NULL, NULL, 'Rev', '2020-09-01 11:07:51'),
(49, 5, NULL, 1, 3, NULL, 8000, 1, 1, 'Cash handover to Arun by Mohit', NULL, 'E', '2020-09-04 16:48:35'),
(50, 5, NULL, 3, 1, 8000, NULL, 1, 1, 'Cash handover to Arun by Mohit', NULL, 'E', '2020-09-04 16:48:35'),
(51, 7, NULL, 5, 3, NULL, 2000, 1, 1, '  Cashhandover to Arun by SC Gupta', NULL, 'E', '2020-09-04 16:50:30'),
(52, 7, NULL, 3, 5, 2000, NULL, 1, 1, '  Cashhandover to Arun by SC Gupta', NULL, 'E', '2020-09-04 16:50:30'),
(53, 33, NULL, 3, NULL, 0, 200, 1, 0, 'Mamta kam wali  41F1 2 days warking 200 ', NULL, 'Exp', '2020-09-04 16:55:47'),
(54, 34, NULL, 3, NULL, 0, 100, 1, 0, 'Sink Jali  41F1 . 100 ', NULL, 'Exp', '2020-09-04 16:57:51'),
(55, 35, NULL, 3, NULL, 0, 500, 1, 0, 'Wagon Petrol  500', NULL, 'Exp', '2020-09-04 17:00:06'),
(56, 36, NULL, 3, NULL, 0, 2350, 1, 0, 'vegitabales  Phase 2 Sabji mandi  2350 Rs Date 04-09-2020', NULL, 'Exp', '2020-09-04 17:06:42'),
(57, 13, 43, 3, NULL, 1000, 0, 1, 0, NULL, NULL, 'Rev', '2020-09-04 17:17:22'),
(58, 14, 4, 3, NULL, 0, 8000, 1, 0, NULL, NULL, 'Rev', '2020-09-04 17:19:39'),
(59, 15, 44, 3, NULL, 2000, 0, 1, 0, NULL, NULL, 'Rev', '2020-09-05 06:14:09'),
(60, 37, NULL, 3, NULL, 0, 320, 1, 0, 'Cupboard Lock 4 ', NULL, 'Exp', '2020-09-05 10:48:18'),
(61, 38, NULL, 3, NULL, 0, 100, 1, 0, 'Door Aldrop set', NULL, 'Exp', '2020-09-05 10:52:19'),
(62, 16, 1, 3, NULL, 11000, 0, 1, 0, NULL, NULL, 'Rev', '2020-09-06 07:40:56'),
(63, 39, NULL, 3, NULL, 0, 11451, 1, 0, 'Catogory Quantity Price\r\nArhar Dal 4kg 400\r\nKala Chana 4kg 280\r\nRajmah 4kg 440\r\nUrad Sabut 3kg 270\r\nChana Dal 4kg 280\r\nkali masoor 4kg 300\r\n Lal masoor 4kg 300\r\nmoong Dhuli 2kg 220\r\nUrad chilka 2kg 200\r\nKabuli Chana  4kg 360\r\nMoong Chilka 1kg 100\r\nAtta 50', NULL, 'Exp', '2020-09-06 13:50:59'),
(64, 12, NULL, 3, NULL, 0, 6000, 1, 0, NULL, NULL, 'Exp', '2020-08-30 16:18:57'),
(65, 11, NULL, 3, NULL, 0, 4776, 1, 0, NULL, NULL, 'Exp', '2020-08-30 15:56:37'),
(66, 17, 6, 3, NULL, 6000, 0, 1, 0, NULL, NULL, 'Rev', '2020-09-07 14:55:16'),
(67, 42, NULL, 3, NULL, 0, 170, 1, 0, ' Fan Capacitor 4 pc 41F1. 2pc  41D1 2pc', NULL, 'Exp', '2020-09-09 10:37:29'),
(68, 43, NULL, 3, NULL, 0, 130, 1, 0, 'Switch . 5 & Socket .1', NULL, 'Exp', '2020-09-09 10:43:03'),
(69, 18, 14, 3, NULL, 17348, 0, 1, 0, NULL, NULL, 'Rev', '2020-09-09 16:19:16'),
(70, 44, NULL, 3, NULL, 0, 180, 1, 0, '5kg Aalu', NULL, 'Exp', '2020-09-10 15:55:08'),
(71, 45, NULL, 3, NULL, 0, 20, 1, 0, 'P B C Tap 2', NULL, 'Exp', '2020-09-10 15:58:54'),
(72, 46, NULL, 3, NULL, 0, 220, 1, 0, 'Tupelight  1 .41G3.S5 ', NULL, 'Exp', '2020-09-10 17:49:28'),
(73, 19, 46, 3, NULL, 120, 0, 1, 0, NULL, NULL, 'Rev', '2020-09-10 18:03:58'),
(74, 9, NULL, 3, 5, NULL, 20000, 1, 1, '  Cash handover to S C Gupta by Arun kumar 20000Rs', NULL, 'E', '2020-09-11 11:48:31'),
(75, 9, NULL, 5, 3, 20000, NULL, 1, 1, '  Cash handover to S C Gupta by Arun kumar 20000Rs', NULL, 'E', '2020-09-11 11:48:31'),
(76, 47, NULL, 3, NULL, 0, 3590, 1, 0, 'Vegitabales KG Price\r\nAalu 15 450\r\nTamatar 10 700\r\npyaj 10 350\r\nBhindi 5 200\r\nArbi 5 130\r\nLauki 5 150\r\nKaddu 5 110\r\npatta gobhi 5 180\r\nkarela 3 105\r\nbaingan 3 105\r\nshimla 3 190\r\nbeans 3 200\r\nadrak 1 160\r\nlasan 0.5 80\r\nmirchi 1 70\r\npaneer 1.5 330\r\nmatar 1 ', NULL, 'Exp', '2020-09-12 13:16:30'),
(77, 48, NULL, 3, NULL, 0, 400, 1, 0, 'Pulsar petrol ', NULL, 'Exp', '2020-09-14 12:27:23'),
(78, 49, NULL, 3, NULL, 0, 2000, 1, 0, 'Jeevan Cook Salary 2000Rs  CV#1120 . Date.14-09-2020', NULL, 'Exp', '2020-09-14 12:35:43'),
(79, 50, NULL, 3, NULL, 0, 200, 1, 0, 'Metre connection cut Line man 200Rs 40C1 date 16 sep 2020', NULL, 'Exp', '2020-09-16 16:59:41'),
(80, 51, NULL, 3, NULL, 0, 200, 1, 0, 'RWA Sweeper  41F1 ', NULL, 'Exp', '2020-09-19 05:07:38'),
(81, 52, NULL, 3, NULL, 0, 150, 1, 0, 'Dosa paste', NULL, 'Exp', '2020-09-20 13:03:18'),
(82, 53, NULL, 3, NULL, 0, 120, 1, 0, 'Faucet Jet Spray', NULL, 'Exp', '2020-09-21 14:08:26'),
(83, 54, NULL, 3, NULL, 0, 300, 1, 0, 'CT 100 Bike Petrol', NULL, 'Exp', '2020-09-21 14:11:33'),
(84, 55, NULL, 3, NULL, 0, 70, 1, 0, '2Kg Aalu', NULL, 'Exp', '2020-09-21 14:13:25'),
(87, 20, 38, 2, NULL, 1020, 0, 1, 0, NULL, NULL, 'Rev', '2020-09-23 17:37:43'),
(89, 13, NULL, 1, 2, NULL, 1980, 1, 1, '  This is a suspense Entry posted to match Yogesh balance as on date of  online application going live', NULL, 'E', '2020-09-23 17:43:34'),
(90, 13, NULL, 2, 1, 1980, NULL, 1, 1, '  This is a suspense Entry posted to match Yogesh balance as on date of  online application going live', NULL, 'E', '2020-09-23 17:43:34'),
(91, 15, NULL, 5, 2, NULL, 10000, 1, 1, '  Cash handover to Yogesh by SC Gupta 10000', NULL, 'E', '2020-09-23 17:45:03'),
(92, 15, NULL, 2, 5, 10000, NULL, 1, 1, '  Cash handover to Yogesh by SC Gupta 10000', NULL, 'E', '2020-09-23 17:45:03'),
(93, 56, NULL, 2, NULL, 0, 500, 1, 0, '9999098840 Mob. Number Recharge 500/-', NULL, 'Exp', '2020-09-23 17:51:27'),
(94, 57, NULL, 2, NULL, 0, 1000, 1, 0, '9999098810 Mob. Recharge 1000/-', NULL, 'Exp', '2020-09-23 17:53:22'),
(95, 58, NULL, 2, NULL, 0, 1499, 1, 0, '9999098842 1 Year Recharge 1499/-', NULL, 'Exp', '2020-09-23 17:55:30'),
(96, 59, NULL, 2, NULL, 0, 3335, 1, 0, 'Vegetables ', NULL, 'Exp', '2020-09-24 09:48:36'),
(97, 60, NULL, 2, NULL, 0, 1200, 1, 0, '2 Geyser Fiting, 4 Swith Board Fix, Inverter Wair Remove , Sheet fix on Mcb Box', NULL, 'Exp', '2020-09-24 15:27:38'),
(98, 22, 4, 2, NULL, 0, 2852, 1, 0, NULL, NULL, 'Rev', '2020-09-24 17:10:26'),
(99, 23, 47, 2, NULL, 9000, 0, 1, 0, NULL, NULL, 'Rev', '2020-09-24 17:56:56'),
(100, 61, NULL, 2, NULL, 0, 300, 1, 0, 'CT 100 petrol 300/-', NULL, 'Exp', '2020-09-26 14:42:22'),
(101, 62, NULL, 3, NULL, 0, 500, 1, 0, 'Amar Singh 500 CV#1122', NULL, 'Exp', '2020-09-26 14:46:18'),
(102, 63, NULL, 2, NULL, 0, 220, 1, 0, 'Tube light purchase sai electrical Barola\r\n220/-', NULL, 'Exp', '2020-09-26 14:49:30'),
(103, 64, NULL, 2, NULL, 0, 250, 1, 0, 'Tube light 20 watt purchase from Barola Sai electrical', NULL, 'Exp', '2020-09-26 14:51:48'),
(104, 65, NULL, 2, NULL, 0, 450, 1, 0, 'Landline Bill pay 450/- 01204348800', NULL, 'Exp', '2020-09-27 05:29:52'),
(105, 66, NULL, 2, NULL, 0, 500, 1, 0, '20 Kg Flour', NULL, 'Exp', '2020-09-27 05:34:05'),
(106, 67, NULL, 2, NULL, 0, 200, 1, 0, '4 Kg Idli Paste', NULL, 'Exp', '2020-09-27 05:35:57'),
(107, 68, NULL, 2, NULL, 0, 24, 1, 0, '500 Ml Milk tea  for Nikita pick luggage ', NULL, 'Exp', '2020-09-27 14:52:26'),
(108, 69, NULL, 2, NULL, 0, 24, 1, 0, '500 Ml Milk tea for New Customer ', NULL, 'Exp', '2020-09-27 14:54:32'),
(109, 70, NULL, 2, NULL, 0, 390, 1, 0, 'Wagon R Petrol 390/-', NULL, 'Exp', '2020-09-28 10:28:00'),
(110, 71, NULL, 2, NULL, 0, 180, 1, 0, 'Board 6A 2*2 from Sai Electricals Barola Mob. No. 9910837988', NULL, 'Exp', '2020-09-28 10:32:11'),
(111, 72, NULL, 2, NULL, 0, 20, 1, 0, '1 Wair Gitty Pkt  from Sai Electricals Barola Mob. No. 9910837988', NULL, 'Exp', '2020-09-28 10:33:57'),
(112, 73, NULL, 2, NULL, 0, 50, 1, 0, 'Wair Striper 50/-', NULL, 'Exp', '2020-09-28 10:51:49'),
(113, 74, NULL, 2, NULL, 0, 20, 1, 0, 'Butter for Dal Makhni 2 Pc 20/-', NULL, 'Exp', '2020-09-29 13:32:37'),
(114, 75, NULL, 2, NULL, 0, 50, 1, 0, 'Capister 50/-', NULL, 'Exp', '2020-09-29 13:33:59'),
(115, 76, NULL, 2, NULL, 0, 60, 1, 0, 'Rajma 500 Gm 60/-', NULL, 'Exp', '2020-09-29 13:34:59'),
(116, 77, NULL, 2, NULL, 0, 24, 1, 0, '500 Ml cow milk', NULL, 'Exp', '2020-10-01 16:05:57'),
(117, 78, NULL, 2, NULL, 0, 5170, 1, 0, 'vegetables Purchase from noida phase 2   5170/-', NULL, 'Exp', '2020-10-02 08:44:08'),
(118, 79, NULL, 2, NULL, 0, 250, 1, 0, 'charger Purchase for Mohit Sir 250/-', NULL, 'Exp', '2020-10-02 08:47:36'),
(119, 80, NULL, 2, NULL, 0, 5500, 1, 0, 'Grocery Purchase 5500/-', NULL, 'Exp', '2020-10-02 08:50:00'),
(120, 81, NULL, 2, NULL, 0, 30, 1, 0, 'wair Gitti Big Pkt  30/-', NULL, 'Exp', '2020-10-04 13:44:53'),
(121, 82, NULL, 2, NULL, 0, 100, 1, 0, '2 kg Idli Paste 100/-', NULL, 'Exp', '2020-10-04 13:46:42'),
(122, 83, NULL, 2, NULL, 0, 642, 1, 0, '4 Kg namak 72/-  15 Kg chini 570/-', NULL, 'Exp', '2020-10-04 13:48:51'),
(123, 84, NULL, 2, NULL, 0, 180, 1, 0, 'Almirah Handle 180/- Grover Hardware Barol Mob.- 9810687514', NULL, 'Exp', '2020-10-04 13:51:40'),
(124, 85, NULL, 2, NULL, 0, 300, 1, 0, 'Ct 100 Petrol 300/-', NULL, 'Exp', '2020-10-05 16:54:07'),
(125, 86, NULL, 2, NULL, 0, 690, 1, 0, 'Bans 6 Pc 115Rs/Pc', NULL, 'Exp', '2020-10-06 05:42:21'),
(126, 87, NULL, 2, NULL, 0, 100, 1, 0, 'Rassi for Bans 100/-', NULL, 'Exp', '2020-10-06 05:43:31'),
(127, 88, NULL, 2, NULL, 0, 100, 1, 0, 'Bans Rikshaw Fair 100/-', NULL, 'Exp', '2020-10-06 05:44:47'),
(128, 89, NULL, 3, NULL, 0, 110, 1, 0, 'Lock 2 pc', NULL, 'Exp', '2020-10-07 11:43:05'),
(129, 24, 49, 2, NULL, 13500, 0, 1, 0, NULL, NULL, 'Rev', '2020-10-07 11:58:46'),
(130, 25, 50, 2, NULL, 11500, 0, 1, 0, NULL, NULL, 'Rev', '2020-10-07 12:08:17'),
(131, 90, NULL, 2, NULL, 0, 100, 1, 0, 'Pressure Cooker Repair 100/- from Kajal kitchen center Mob. No. 9811824092 ', NULL, 'Exp', '2020-10-08 17:09:03'),
(132, 91, NULL, 2, NULL, 0, 3365, 1, 0, 'Grocery Purchase From Barola 3365/-', NULL, 'Exp', '2020-10-08 17:21:51'),
(133, 26, 43, 3, NULL, 104, 0, 1, 0, NULL, NULL, 'Rev', '2020-10-08 17:24:19'),
(136, 92, NULL, 3, NULL, 0, 272, 1, 0, 'staff tv Recharge  41F1F3 272Rs ', NULL, 'Exp', '2020-10-14 12:48:07'),
(137, 27, 2, 2, NULL, 10000, 0, 1, 0, NULL, NULL, 'Rev', '2020-10-14 13:13:19'),
(138, 93, NULL, 2, NULL, 0, 500, 1, 0, 'Eeco Petral ', NULL, 'Exp', '2020-10-14 13:15:47'),
(139, 94, NULL, 2, NULL, 0, 375, 1, 0, 'Eeco CNG', NULL, 'Exp', '2020-10-14 13:18:18'),
(140, 95, NULL, 2, NULL, 0, 2740, 1, 0, '9 Bed sifting &26side tabal', NULL, 'Exp', '2020-10-14 13:23:09'),
(141, 96, NULL, 2, NULL, 0, 600, 1, 0, '1 Gas cylinder ', NULL, 'Exp', '2020-10-14 13:26:12'),
(142, 97, NULL, 2, NULL, 0, 910, 1, 0, '9 Bed Shifing  Riksha', NULL, 'Exp', '2020-10-14 13:35:30'),
(143, 98, NULL, 2, NULL, 0, 300, 1, 0, 'Eeco tyre repair 2', NULL, 'Exp', '2020-10-14 13:39:16'),
(144, 28, 14, 2, NULL, 20500, 0, 1, 0, NULL, NULL, 'Rev', '2020-10-14 13:43:18'),
(146, 100, NULL, 2, NULL, 0, 150, 1, 0, 'Idli paste 3kg', NULL, 'Exp', '2020-10-14 13:45:19'),
(147, 101, NULL, 2, NULL, 0, 266, 1, 0, '1days Salary  Sarvesh kumar', NULL, 'Exp', '2020-10-14 13:49:04'),
(148, 102, NULL, 2, NULL, 0, 20, 1, 0, 'Halder 1 pc', NULL, 'Exp', '2020-10-14 13:51:53'),
(149, 103, NULL, 2, NULL, 0, 21, 1, 0, '3Mtr pipe ', NULL, 'Exp', '2020-10-14 13:54:22'),
(150, 104, NULL, 2, NULL, 0, 40, 1, 0, '1 tokri ', NULL, 'Exp', '2020-10-14 13:55:41'),
(151, 105, NULL, 2, NULL, 0, 2440, 1, 0, '1 tin .1500                                                                                                                                                                                                                                                    ', NULL, 'Exp', '2020-10-14 14:05:09'),
(152, 106, NULL, 2, NULL, 0, 3205, 1, 0, 'vegetables', NULL, 'Exp', '2020-10-14 14:06:49'),
(153, 107, NULL, 2, NULL, 0, 150, 1, 0, '2 Rassi rent', NULL, 'Exp', '2020-10-14 14:10:12'),
(154, 29, 51, 2, NULL, 2000, 0, 1, 0, NULL, NULL, 'Rev', '2020-10-14 17:34:20'),
(155, 19, NULL, 2, 1, NULL, 30000, 1, 1, 'cash hand over mohit sir by yogesh 30000', NULL, 'E', '2020-10-14 17:56:53'),
(156, 19, NULL, 1, 2, 30000, NULL, 1, 1, 'cash hand over mohit sir by yogesh 30000', NULL, 'E', '2020-10-14 17:56:53'),
(157, 21, NULL, 2, 1, NULL, 10000, 1, 1, '  cash hand over to mohit sir by yogesh salary ', NULL, 'E', '2020-10-14 18:02:36'),
(158, 21, NULL, 1, 2, 10000, NULL, 1, 1, '  cash hand over to mohit sir by yogesh salary ', NULL, 'E', '2020-10-14 18:02:36'),
(159, 23, NULL, 3, 2, NULL, 3000, 1, 1, '  cash hand over to arun by yogesh 3000', NULL, 'E', '2020-10-14 18:07:23'),
(160, 23, NULL, 2, 3, 3000, NULL, 1, 1, '  cash hand over to arun by yogesh 3000', NULL, 'E', '2020-10-14 18:07:23'),
(161, 108, NULL, 3, NULL, 0, 162, 1, 0, 'Medicine navistar 5mg 1 patta   mohit sir ', NULL, 'Exp', '2020-10-15 13:13:11'),
(162, 109, NULL, 3, NULL, 0, 228, 1, 0, 'Medicine T.sart H 40mg 1patta  mohit sir ', NULL, 'Exp', '2020-10-15 13:17:27'),
(163, 25, NULL, 4, 2, NULL, 10000, 5, 1, '   Excess salary tfd to yogesh via Rajni curr ac...withdrawn by him in cash ', NULL, 'E', '2020-10-19 17:15:51'),
(164, 25, NULL, 2, 4, 10000, NULL, 1, 5, '   Excess salary tfd to yogesh via Rajni curr ac...withdrawn by him in cash ', NULL, 'E', '2020-10-19 17:15:51'),
(165, 27, NULL, 4, 3, NULL, 3000, 1, 1, '  cash handed over by mohit to Arun.', NULL, 'E', '2020-10-19 17:19:51'),
(166, 27, NULL, 3, 4, 3000, NULL, 1, 1, '  cash handed over by mohit to Arun.', NULL, 'E', '2020-10-19 17:19:51'),
(168, 110, NULL, 3, NULL, 0, 220, 1, 0, 'Serew Driver sat ( Taparia)', NULL, 'Exp', '2020-10-20 09:41:43'),
(169, 111, NULL, 3, NULL, 0, 30, 1, 0, 'Drill bit', NULL, 'Exp', '2020-10-20 09:45:45'),
(170, 112, NULL, 3, NULL, 0, 230, 1, 0, 'Ludo ', NULL, 'Exp', '2020-10-20 09:48:14'),
(171, 113, NULL, 3, NULL, 0, 300, 1, 0, 'Wagonr Petrol', NULL, 'Exp', '2020-10-20 09:51:56'),
(172, 114, NULL, 3, NULL, 0, 1890, 1, 0, 'Eeco Service', NULL, 'Exp', '2020-10-20 09:54:37'),
(173, 115, NULL, 3, NULL, 0, 3240, 1, 0, 'Grocery', NULL, 'Exp', '2020-10-20 10:03:11'),
(174, 31, 51, 3, NULL, 3420, 0, 1, 0, NULL, NULL, 'Rev', '2020-10-20 10:08:20'),
(175, 32, 52, 3, NULL, 1000, 0, 1, 0, NULL, NULL, 'Rev', '2020-10-20 10:16:13'),
(176, 116, NULL, 3, NULL, 0, 220, 1, 0, '3kg noodles', NULL, 'Exp', '2020-10-20 10:20:11'),
(177, 117, NULL, 3, NULL, 0, 100, 1, 0, 'Patta Gobi 1.5kg ', NULL, 'Exp', '2020-10-20 10:23:02'),
(178, 118, NULL, 3, NULL, 0, 80, 1, 0, 'Semla mirch 500gm', NULL, 'Exp', '2020-10-20 10:25:11'),
(179, 119, NULL, 2, NULL, 0, 200, 1, 0, 'Welding D157 for shaft 200Rs ', NULL, 'Exp', '2020-10-20 10:48:10'),
(180, 120, NULL, 2, NULL, 0, 125, 1, 0, 'Grinder machine gitti', NULL, 'Exp', '2020-10-20 10:51:34'),
(181, 33, 10, 3, NULL, 9000, 0, 1, 0, NULL, NULL, 'Rev', '2020-10-27 06:55:32'),
(182, 34, 53, 3, NULL, 2000, 0, 1, 0, NULL, NULL, 'Rev', '2020-10-27 07:02:46'),
(183, 121, NULL, 3, NULL, 0, 10000, 1, 0, 'Irfan Welder 41D1  10000 Cash CV#1126', NULL, 'Exp', '2020-10-31 15:46:44'),
(188, 33, NULL, 3, 2, NULL, 17000, 1, 1, '  Cash hand over to yogesh by arun', NULL, 'E', '2020-11-05 10:50:11'),
(189, 33, NULL, 2, 3, 17000, NULL, 1, 1, '  Cash hand over to yogesh by arun', NULL, 'E', '2020-11-05 10:50:11'),
(190, 35, NULL, 3, 4, NULL, 20000, 5, 5, '  Cash hand over to Rajni Poddar by Arun Kumar', NULL, 'E', '2020-11-05 10:55:47'),
(191, 35, NULL, 4, 3, 20000, NULL, 5, 5, '  Cash hand over to Rajni Poddar by Arun Kumar', NULL, 'E', '2020-11-05 10:55:47'),
(192, 122, NULL, 3, NULL, 0, 2000, 1, 0, 'Jeevan Salary 2000CV#1128', NULL, 'Exp', '2020-11-05 11:00:42'),
(193, 35, 14, 3, NULL, 19000, 0, 1, 0, NULL, NULL, 'Rev', '2020-11-05 16:11:08'),
(194, 123, NULL, 3, NULL, 0, 400, 1, 0, 'wagon R petrol 400RS ', NULL, 'Exp', '2020-11-06 11:00:34'),
(195, 36, 1, 2, NULL, 18432, 0, 1, 0, NULL, NULL, 'Rev', '2020-11-06 16:08:51'),
(196, 37, 54, 2, NULL, 1000, 0, 1, 0, NULL, NULL, 'Rev', '2020-11-06 16:16:44'),
(197, 38, 53, 2, NULL, 7500, 0, 1, 0, NULL, NULL, 'Rev', '2020-11-06 16:19:26'),
(198, 39, 17, 2, NULL, 6000, 0, 1, 0, NULL, NULL, 'Rev', '2020-11-06 16:28:39'),
(199, 40, 50, 2, NULL, 10720, 0, 1, 0, NULL, NULL, 'Rev', '2020-11-06 16:30:54'),
(200, 41, 49, 2, NULL, 13500, 0, 1, 0, NULL, NULL, 'Rev', '2020-11-06 16:34:29'),
(201, 42, 55, 2, NULL, 2000, 0, 1, 0, NULL, NULL, 'Rev', '2020-11-06 16:42:35'),
(202, 43, 2, 2, NULL, 10000, 0, 1, 0, NULL, NULL, 'Rev', '2020-11-06 16:44:36'),
(203, 44, 4, 2, NULL, 0, 13756, 1, 0, NULL, NULL, 'Rev', '2020-11-06 16:47:30'),
(204, 37, NULL, 2, 1, NULL, 10000, 1, 1, '  Cash hand over to mohit sir by yogesh', NULL, 'E', '2020-11-06 16:53:46'),
(205, 37, NULL, 1, 2, 10000, NULL, 1, 1, '  Cash hand over to mohit sir by yogesh', NULL, 'E', '2020-11-06 16:53:46'),
(206, 124, NULL, 3, NULL, 0, 213, 1, 0, '9999098810 Recharge 213', NULL, 'Exp', '2020-11-11 06:42:19'),
(207, 125, NULL, 3, NULL, 0, 240, 1, 0, '10kg Atta', NULL, 'Exp', '2020-11-11 06:43:57'),
(208, 126, NULL, 3, NULL, 0, 70, 1, 0, '250gm Tea', NULL, 'Exp', '2020-11-11 06:45:49'),
(209, 39, NULL, 3, 2, NULL, 500, 1, 1, 'Cash hand Over to yogesh  500 by arun', NULL, 'E', '2020-11-11 06:48:38'),
(210, 39, NULL, 2, 3, 500, NULL, 1, 1, 'Cash hand Over to yogesh  500 by arun', NULL, 'E', '2020-11-11 06:48:38'),
(211, 127, NULL, 3, NULL, 0, 60, 1, 0, 'Coold Dringk  200ml 4.  60Rs', NULL, 'Exp', '2020-11-11 06:52:11'),
(212, 128, NULL, 3, NULL, 0, 20, 1, 0, 'Good day Biskit 20', NULL, 'Exp', '2020-11-11 06:54:08'),
(213, 129, NULL, 3, NULL, 0, 20, 1, 0, 'Lays Chips 20', NULL, 'Exp', '2020-11-11 06:55:22'),
(214, 130, NULL, 3, NULL, 0, 10, 1, 0, 'ilayachi 1 pkt 10', NULL, 'Exp', '2020-11-11 06:56:38'),
(215, 131, NULL, 3, NULL, 0, 20, 1, 0, 'Disposal Galass 4 pc 20', NULL, 'Exp', '2020-11-11 06:58:09'),
(216, 132, NULL, 3, NULL, 0, 28, 1, 0, '1pkt Milk 28', NULL, 'Exp', '2020-11-11 06:59:23'),
(217, 133, NULL, 3, NULL, 0, 200, 1, 0, 'Sweeper 41G1 200', NULL, 'Exp', '2020-11-11 07:03:08'),
(218, 134, NULL, 3, NULL, 0, 4280, 1, 0, 'Vagitabals  4280', NULL, 'Exp', '2020-11-11 07:04:47'),
(219, 135, NULL, 3, NULL, 0, 290, 1, 0, 'Eeco CNG 290', NULL, 'Exp', '2020-11-11 07:07:02'),
(220, 136, NULL, 3, NULL, 0, 8000, 1, 0, 'Sarvesh salary 8000 CV#1136', NULL, 'Exp', '2020-11-11 07:11:41'),
(221, 137, NULL, 3, NULL, 0, 2000, 1, 0, 'Jeevan Salary 2000 CV#1137', NULL, 'Exp', '2020-11-11 07:14:44'),
(222, 138, NULL, 3, NULL, 0, 20, 1, 0, 'Photo copy 20', NULL, 'Exp', '2020-11-11 07:17:00'),
(223, 139, NULL, 3, NULL, 0, 70, 1, 0, 'Diya 45 Diwali ke liye ', NULL, 'Exp', '2020-12-21 07:12:05'),
(224, 140, NULL, 3, NULL, 0, 30, 1, 0, 'Cotton 3 pkt', NULL, 'Exp', '2020-12-21 07:13:43'),
(225, 141, NULL, 3, NULL, 0, 210, 1, 0, 'Til ka oil 3 bottal', NULL, 'Exp', '2020-12-21 07:15:11'),
(226, 142, NULL, 3, NULL, 0, 2900, 1, 0, 'Tirpal', NULL, 'Exp', '2020-12-21 07:17:12'),
(227, 143, NULL, 3, NULL, 0, 240, 1, 0, 'Walcrw ', NULL, 'Exp', '2020-12-21 07:19:05'),
(228, 144, NULL, 3, NULL, 0, 290, 1, 0, 'LOOPi', NULL, 'Exp', '2020-12-21 07:20:17'),
(229, 145, NULL, 3, NULL, 0, 350, 1, 0, 'Azad market to noida uber', NULL, 'Exp', '2020-12-21 07:22:43'),
(230, 146, NULL, 3, NULL, 0, 500, 1, 0, 'Tailor', NULL, 'Exp', '2020-12-21 07:24:09'),
(231, 147, NULL, 3, NULL, 0, 150, 1, 0, 'Lunch', NULL, 'Exp', '2020-12-21 07:25:21'),
(232, 148, NULL, 3, NULL, 0, 150, 1, 0, 'fastener 10 pc', NULL, 'Exp', '2020-12-21 07:28:09'),
(233, 149, NULL, 3, NULL, 0, 70, 1, 0, 'Drill machine bit', NULL, 'Exp', '2020-12-21 07:31:21'),
(234, 150, NULL, 3, NULL, 0, 24, 1, 0, 'Cow milk 1 500ml', NULL, 'Exp', '2020-12-21 07:36:27'),
(235, 151, NULL, 3, NULL, 0, 23, 1, 0, 'Tonde  milk 1 500ml', NULL, 'Exp', '2020-12-21 07:38:17'),
(236, 45, 56, 3, NULL, 2000, 0, 1, 0, NULL, NULL, 'Rev', '2020-12-21 07:48:59'),
(237, 46, 57, 3, NULL, 10500, 0, 1, 0, NULL, NULL, 'Rev', '2020-12-21 08:00:48'),
(238, 47, 14, 3, NULL, 17150, 0, 1, 0, NULL, NULL, 'Rev', '2020-12-21 08:03:47'),
(239, 48, 1, 3, NULL, 10000, 0, 1, 0, NULL, NULL, 'Rev', '2020-12-21 08:06:11'),
(240, 152, NULL, 3, NULL, 0, 4000, 1, 0, 'mother Dairy advanec 4000  Date 05-dec-20\r\n', NULL, 'Exp', '2020-12-21 13:05:52'),
(241, 153, NULL, 3, NULL, 0, 23, 1, 0, 'Tonde 500ml', NULL, 'Exp', '2020-12-21 13:07:19'),
(242, 154, NULL, 3, NULL, 0, 24, 1, 0, 'cow milk 500ml', NULL, 'Exp', '2020-12-21 13:08:54'),
(243, 155, NULL, 3, NULL, 0, 90, 1, 0, 'PVC Pipe  cap 1pc', NULL, 'Exp', '2020-12-21 13:10:45'),
(244, 156, NULL, 3, NULL, 0, 60, 1, 0, 'M Seal 1pkt', NULL, 'Exp', '2020-12-21 13:12:46'),
(245, 41, NULL, 3, 2, NULL, 3000, 1, 1, 'Cash hand over from yogesh to arun', NULL, 'E', '2020-12-21 13:18:30'),
(246, 41, NULL, 2, 3, 3000, NULL, 1, 1, 'Cash hand over from yogesh to arun', NULL, 'E', '2020-12-21 13:18:30'),
(247, 157, NULL, 3, NULL, 0, 23, 1, 0, 'Tonde 500ml', NULL, 'Exp', '2020-12-21 13:22:44'),
(248, 158, NULL, 3, NULL, 0, 24, 1, 0, 'Cow milk 500ml', NULL, 'Exp', '2020-12-21 13:24:15'),
(249, 159, NULL, 3, NULL, 0, 40, 1, 0, 'Bread 1pkt', NULL, 'Exp', '2020-12-21 13:26:05'),
(250, 160, NULL, 3, NULL, 0, 150, 1, 0, '2kg  noodles', NULL, 'Exp', '2020-12-21 13:28:06'),
(251, 161, NULL, 3, NULL, 6000, 0, 1, 0, '2Cpboard 6000 Recd Arun by 9634727419 Date 06-dec-20', NULL, 'Exp', '2020-12-21 13:34:53'),
(254, 45, NULL, 3, 1, NULL, 50000, 1, 1, '  Cash hand Over to mohit sir from Arun', NULL, 'E', '2020-12-21 13:43:08'),
(255, 45, NULL, 1, 3, 50000, NULL, 1, 1, '  Cash hand Over to mohit sir from Arun', NULL, 'E', '2020-12-21 13:43:08'),
(258, 49, NULL, 3, 1, NULL, 500, 1, 1, 'Cash hand over mohit sir by arun', NULL, 'E', '2020-12-21 13:49:25'),
(259, 49, NULL, 1, 3, 500, NULL, 1, 1, 'Cash hand over mohit sir by arun', NULL, 'E', '2020-12-21 13:49:25'),
(260, 162, NULL, 3, NULL, 0, 2637, 1, 0, 'Rajendar mather dairy pament 2637 CV#1139 date 07-12-20', NULL, 'Exp', '2020-12-21 13:54:40'),
(261, 163, NULL, 3, NULL, 0, 850, 1, 0, 'Gas cylinder', NULL, 'Exp', '2020-12-21 13:57:46'),
(262, 164, NULL, 3, NULL, 0, 47, 1, 0, 'Tonde 1ltr', NULL, 'Exp', '2020-12-21 13:59:37'),
(263, 165, NULL, 3, NULL, 0, 24, 1, 0, 'Cow milk 500ml', NULL, 'Exp', '2020-12-21 14:01:19'),
(264, 166, NULL, 3, NULL, 0, 300, 1, 0, 'Eeco petrol', NULL, 'Exp', '2020-12-21 14:03:36'),
(265, 167, NULL, 3, NULL, 0, 150, 1, 0, 'Teapatti', NULL, 'Exp', '2020-12-21 14:05:26'),
(266, 49, 20, 3, NULL, 30000, 0, 1, 0, NULL, NULL, 'Rev', '2020-12-21 14:09:04'),
(267, 168, NULL, 3, NULL, 3000, 0, 1, 0, '1 Copbard or 1 bed 3000 by Jatindar 8218924491', NULL, 'Exp', '2020-12-21 14:13:07'),
(268, 169, NULL, 3, NULL, 0, 500, 1, 0, 'AC Sfting 40c1 to 41D1', NULL, 'Exp', '2020-12-21 14:16:26'),
(269, 170, NULL, 3, NULL, 0, 500, 1, 0, '20kg Atta\r\n  ', NULL, 'Exp', '2020-12-21 14:18:43'),
(270, 51, NULL, 3, 2, NULL, 10000, 1, 1, '  Cash hand over arun to yogesh 10000', NULL, 'E', '2020-12-21 14:20:57'),
(271, 51, NULL, 2, 3, 10000, NULL, 1, 1, '  Cash hand over arun to yogesh 10000', NULL, 'E', '2020-12-21 14:20:57'),
(272, 171, NULL, 3, NULL, 1000, 0, 1, 0, '1 Bed Ravindar 1000', NULL, 'Exp', '2020-12-21 14:23:35'),
(273, 53, NULL, 3, 2, NULL, 4000, 1, 1, '  Cash hand over arun to Yagesh', NULL, 'E', '2020-12-21 14:25:47'),
(274, 53, NULL, 2, 3, 4000, NULL, 1, 1, '  Cash hand over arun to Yagesh', NULL, 'E', '2020-12-21 14:25:47'),
(275, 172, NULL, 3, NULL, 0, 5096, 1, 0, 'Rope Light ', NULL, 'Exp', '2020-12-22 11:24:17'),
(276, 173, NULL, 3, NULL, 0, 5096, 1, 0, 'Rope Light ', NULL, 'Exp', '2020-12-22 11:24:17');

-- --------------------------------------------------------

--
-- Table structure for table `invoice`
--

CREATE TABLE `invoice` (
  `invoice_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `month` varchar(255) NOT NULL,
  `amount` int(11) NOT NULL,
  `total_amount` int(11) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `invoice`
--

INSERT INTO `invoice` (`invoice_id`, `customer_id`, `month`, `amount`, `total_amount`, `status`) VALUES
(1, 2, '02-2020', 3000, 3000, 0),
(2, 3, '02-2020', 6000, 6000, 0),
(3, 1001, '02-2020', 17000, 17000, 0),
(4, 1002, '02-2020', 13000, 13000, 0),
(5, 1003, '02-2020', 13000, 13000, 0),
(6, 1004, '02-2020', 14000, 14000, 0),
(7, 1017, '02-2020', 2000, 2000, 0),
(8, 1005, '02-2020', 14500, 14500, 0),
(9, 1006, '02-2020', 13000, 13000, 0),
(10, 1007, '02-2020', 13000, 13000, 0),
(11, 1008, '02-2020', 10500, 10500, 0),
(12, 1009, '02-2020', 10500, 10500, 0),
(13, 1010, '02-2020', 13000, 13000, 0),
(14, 1011, '02-2020', 13000, 13000, 0),
(15, 1012, '02-2020', 10500, 10500, 0),
(16, 1013, '02-2020', 10500, 10500, 0),
(17, 1014, '02-2020', 10500, 10500, 0),
(18, 1015, '02-2020', 13000, 13000, 0),
(19, 1016, '02-2020', 14000, 14000, 0),
(20, 1018, '02-2020', 7500, 7500, 0),
(21, 1019, '02-2020', 11500, 11500, 0),
(22, 1020, '02-2020', 12000, 12000, 0),
(23, 1021, '02-2020', 9000, 9000, 0),
(24, 1022, '02-2020', 9000, 9000, 0),
(25, 1023, '02-2020', 9000, 9000, 0),
(26, 1024, '02-2020', 9000, 9000, 0),
(27, 1025, '02-2020', 9000, 9000, 0),
(28, 1026, '02-2020', 7500, 7500, 0),
(29, 1027, '02-2020', 7500, 7500, 0),
(30, 1028, '02-2020', 10000, 10000, 0),
(31, 1029, '02-2020', 10500, 10500, 0),
(32, 1030, '02-2020', 9000, 9000, 0),
(33, 1031, '02-2020', 9500, 9500, 0),
(34, 1032, '02-2020', 9500, 9500, 0),
(35, 1033, '02-2020', 7500, 7500, 0),
(36, 1034, '02-2020', 8000, 8000, 0),
(37, 1035, '02-2020', 11900, 11900, 0),
(38, 1036, '02-2020', 10000, 10000, 0),
(39, 1037, '02-2020', 7000, 7000, 0),
(40, 1038, '02-2020', 17000, 17000, 0),
(41, 1039, '02-2020', 20000, 20000, 0),
(42, 1040, '02-2020', 11000, 11000, 0),
(43, 1041, '02-2020', 11000, 11000, 0),
(44, 1042, '02-2020', 11000, 11000, 0),
(45, 1043, '02-2020', 11000, 11000, 0),
(46, 1044, '02-2020', 7250, 7250, 0),
(47, 1045, '02-2020', 9500, 9500, 0),
(48, 1046, '02-2020', 9000, 9000, 0),
(49, 1047, '02-2020', 10000, 10000, 0),
(50, 1048, '02-2020', 10000, 10000, 0),
(51, 1049, '02-2020', 9500, 9500, 0),
(52, 1050, '02-2020', 10500, 10500, 0),
(53, 1051, '02-2020', 13000, 13000, 0),
(54, 1052, '02-2020', 10500, 10500, 0),
(55, 1053, '02-2020', 10500, 10500, 0),
(56, 1054, '02-2020', 9000, 9000, 0),
(57, 1055, '02-2020', 9000, 9000, 0),
(58, 1056, '02-2020', 10000, 10000, 0),
(59, 1057, '02-2020', 10000, 10000, 0),
(60, 1058, '02-2020', 12500, 12500, 0),
(61, 1059, '02-2020', 11500, 11500, 0),
(62, 1060, '02-2020', 11500, 11500, 0),
(63, 1061, '02-2020', 8000, 8000, 0),
(64, 1062, '02-2020', 8000, 8000, 0),
(65, 1063, '02-2020', 8000, 8000, 0),
(66, 1064, '02-2020', 7000, 7000, 0),
(67, 1065, '02-2020', 7000, 7000, 0),
(68, 1066, '02-2020', 7000, 7000, 0),
(69, 1067, '02-2020', 9500, 9500, 0),
(70, 1068, '02-2020', 9500, 9500, 0),
(71, 1069, '02-2020', 11500, 11500, 0),
(72, 1070, '02-2020', 11500, 11500, 0),
(73, 1071, '02-2020', 10500, 10500, 0),
(74, 1072, '02-2020', 9500, 9500, 0),
(75, 1073, '02-2020', 9500, 9500, 0),
(76, 1074, '02-2020', 11500, 11500, 0),
(77, 1075, '02-2020', 10000, 10000, 0),
(78, 1076, '02-2020', 8000, 8000, 0),
(79, 1077, '02-2020', 9000, 9000, 0),
(80, 1078, '02-2020', 9000, 9000, 0),
(81, 1079, '02-2020', 12000, 12000, 0),
(82, 1080, '02-2020', 10500, 10500, 0),
(83, 1081, '02-2020', 10000, 10000, 0),
(84, 1082, '02-2020', 11500, 11500, 0),
(85, 1083, '02-2020', 12500, 12500, 0),
(86, 1084, '02-2020', 12500, 12500, 0),
(87, 1085, '02-2020', 12500, 12500, 0),
(88, 1086, '02-2020', 11000, 11000, 0),
(89, 1087, '02-2020', 12000, 12000, 0),
(90, 1088, '02-2020', 11000, 11000, 0),
(91, 1089, '02-2020', 11000, 11000, 0),
(92, 1090, '02-2020', 17500, 17500, 0),
(93, 1091, '02-2020', 20000, 20000, 0),
(94, 1092, '02-2020', 18500, 18500, 0),
(95, 1093, '02-2020', 12500, 12500, 0),
(96, 1094, '02-2020', 12000, 12000, 0),
(97, 1095, '02-2020', 7500, 7500, 0),
(98, 1096, '03-2020', 5000, 5000, 0),
(99, 18, '03-2020', 18500, 18500, 0),
(100, 17, '03-2020', 12000, 12000, 0),
(101, 1, '03-2020', 1, 1, 0),
(102, 18, '03-2020', 7000, 7000, 0),
(103, 1, '04-2020', 10000, 10000, 0),
(104, 19, '04-2020', 9000, 9000, 0),
(105, 19, '04-2020', 9000, 9000, 0),
(106, 19, '04-2020', 9000, 9000, 0),
(107, 19, '04-2020', 9000, 9000, 0),
(108, 18, '04-2020', 18000, 18000, 0),
(109, 19, '04-2020', 9000, 9000, 0),
(110, 1, '08-2020', 10000, 10000, 0),
(111, 4, '08-2020', 8000, 8000, 0),
(112, 3, '08-2020', 12000, 12000, 0),
(113, 2, '08-2020', 10000, 10000, 0),
(114, 5, '08-2020', 8000, 8000, 0),
(115, 6, '08-2020', 6000, 6000, 0),
(116, 8, '08-2020', 5000, 5000, 0),
(117, 9, '08-2020', 9000, 9000, 0),
(118, 1, '08-2020', 10000, 10000, 0),
(119, 10, '08-2020', 9000, 9000, 0),
(120, 11, '08-2020', 10000, 10000, 0),
(121, 12, '08-2020', 10000, 10000, 0),
(122, 13, '08-2020', 9000, 9000, 0),
(123, 14, '08-2020', 15000, 15000, 0),
(124, 15, '08-2020', 8000, 8000, 0),
(125, 16, '08-2020', 11000, 11000, 0),
(126, 17, '08-2020', 12000, 12000, 0),
(127, 18, '08-2020', 11500, 11500, 0),
(128, 19, '08-2020', 20000, 20000, 0),
(129, 20, '08-2020', 17500, 17500, 0),
(130, 21, '08-2020', 12000, 12000, 0),
(131, 22, '08-2020', 9000, 9000, 0),
(132, 23, '08-2020', 8000, 8000, 0),
(133, 23, '08-2020', 8000, 8000, 0),
(134, 24, '08-2020', 8000, 8000, 0),
(135, 25, '08-2020', 8000, 8000, 0),
(136, 24, '08-2020', 8000, 8000, 0),
(137, 28, '08-2020', 8000, 8000, 0),
(138, 32, '08-2020', 13000, 13000, 0),
(139, 33, '08-2020', 13000, 13000, 0),
(140, 34, '08-2020', 10500, 10500, 0),
(141, 35, '08-2020', 12500, 12500, 0),
(142, 36, '08-2020', 14000, 14000, 0),
(143, 37, '08-2020', 10000, 10000, 0),
(144, 38, '08-2020', 6000, 6000, 0),
(145, 39, '08-2020', 11500, 11500, 0),
(146, 40, '08-2020', 8000, 8000, 0),
(147, 41, '08-2020', 8500, 8500, 0),
(148, 42, '08-2020', 10500, 10500, 0),
(149, 43, '09-2020', 7000, 7000, 0),
(150, 44, '09-2020', 7000, 7000, 0),
(151, 46, '09-2020', 10000, 10000, 0),
(152, 47, '09-2020', 9000, 9000, 0),
(153, 48, '09-2020', 13000, 13000, 0),
(154, 49, '10-2020', 9000, 9000, 0),
(155, 49, '10-2020', 9000, 9000, 0),
(156, 50, '10-2020', 9000, 9000, 0),
(157, 51, '10-2020', 7000, 7000, 0),
(158, 52, '10-2020', 7000, 7000, 0),
(159, 53, '10-2020', 9500, 9500, 0),
(160, 54, '11-2020', 6500, 6500, 0),
(161, 55, '11-2020', 11500, 11500, 0),
(162, 56, '12-2020', 9000, 9000, 0),
(163, 57, '12-2020', 7000, 7000, 0);

-- --------------------------------------------------------

--
-- Table structure for table `invoice_install`
--

CREATE TABLE `invoice_install` (
  `invoice_instaill_id` int(11) NOT NULL,
  `invoice_id` int(11) NOT NULL,
  `amount` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `id` int(11) NOT NULL,
  `log_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `number` bigint(11) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `designation` int(11) DEFAULT NULL,
  `type` varchar(255) NOT NULL COMMENT '1=admin 2=emp 3=user 4=super admin 5=vender',
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `log_id`, `name`, `number`, `email`, `password`, `designation`, `type`, `status`) VALUES
(1, 1, 'Mohit Gupta', 9810565610, 'gguptamohit@gmail.com', 'e3b04a1c4e4485b3db7152214190ec33', NULL, '4', 1),
(2, 2, 'Abhimanyu', 8800779299, 'stayinclassluxurypg@gmail.com', '9c247d5a2380f91279237463bfdc4d2a', NULL, '1', 1),
(3, 3, 'Arun', 9999098810, 'Stayinclassluxurypg@gmail.com', '27352b2261b96e0a82ea98e881c68d1b', NULL, '1', 1),
(4, 1, 'Saloni Rastogi', 8800483459, 'temp@gmail.com', '710a0be9da191619f2bdec147aa47e76', NULL, '3', 1),
(5, 2, 'Vaishali', 8800483459, 'vaishali@Gmali.com', '710a0be9da191619f2bdec147aa47e76', NULL, '3', 1),
(6, 3, 'Sara Sriwastava', 7836058234, 'sarasriwastava210@Gmali.com', '03e9a33b4cac8de2f6dbc2728aa9ce1d', NULL, '3', 1),
(7, 4, 'mohini yadav', 8126412272, 'mohini1996@Gmali.com', '9b9e1dc3987728693a650d21217ea830', NULL, '3', 1),
(8, 5, 'Taniya sharma', 9888969779, 'taniyasharma01111@Gmali.com', 'ed9caeab1d926ad3521f831218af15e4', NULL, '3', 1),
(9, 6, 'Jyoti Awasthi', 7607849975, 'jyotiawasthi@Gmali.com', 'd682193643c85cd967093263de5cd761', NULL, '3', 1),
(11, 8, 'Mahima', 9821116798, 'mahima@1991Gmali.com', '9704204be0c3033b166b0a092d407714', NULL, '3', 1),
(12, 9, 'Priya Pandey', 7985793299, 'priyapandey@Gmali.com', '085ae4f27b9d28924338dc9bf160873d', NULL, '3', 1),
(13, 10, 'Deepti Singh', 9650871936, 'deeptisingh@Gmali.com', 'd4dc6eb3ebbc6d51a65aea9820a3de2f', NULL, '3', 1),
(14, 11, 'Versha Koul', 8587003117, 'vershakoul@gmali.com', '13e32a9e80f24f134b51b89f71f3dde3', NULL, '3', 1),
(15, 12, 'Vishakha Chaursia', 9711094582, 'vishakhachaursia@Gmali.com', '60be564b8b39063211b395f213717132', NULL, '3', 1),
(16, 13, 'Khusboo Singh', 9654798082, 'khusboosingh@Gmali.com', '36c72c75bca023bbe597f7bd7d92fc4a', NULL, '3', 1),
(17, 14, 'Viveka Shahi', 9821793507, 'vivekashahi@gmali.com', '00bd01faf72e8f11f26a6cd81e545051', NULL, '3', 1),
(18, 15, 'Divya Paliwal', 8529740850, 'DivyaPaliwal@Gmali.com', '86809be6ce58a5037f535e3cd35b6939', NULL, '3', 1),
(20, 17, 'Shaayal Mishra', 9628461105, 'mishrashaayal@Gmali.com', '9bc388c1caad1ecfa5a5f7c414110b75', NULL, '3', 1),
(21, 18, 'Madhu - 10315', 9868976377, 'Madhu@gmali.com', '73a1c10d9ae0d36ee5c579be9f0e5f30', NULL, '3', 1),
(22, 19, 'Ayilya Thampuran', 9711141423, 'ayilyathampuran@Gmali.com', '2eff7db2927372fe36e4cb33eb9bc26f', NULL, '3', 1),
(23, 20, 'Devangi Garg', 9997521114, 'devangigarg@Gmali.com', '7abc90d23ff0a990e24e66096f902f26', NULL, '3', 1),
(24, 21, 'Mandakini Kumar', 9910056233, 'mandakini.kukar@yahoo.com', 'c2a4c13aa4014e856704310815731b26', NULL, '3', 1),
(25, 22, 'Jyotsana', 8899309621, 'Jyotsana@Gmali.com', 'a5ea343f5f17c63c9a2afcc01d9c5b58', NULL, '3', 1),
(26, 23, 'Shivank - 10320', 9325467956, 'shivank@Gmali.com', '54540d09f35a4533b6e255a98f83e41b', NULL, '3', 1),
(27, 24, 'Nikita Jaiswal', 8527110909, 'nikitajaiswal@Gmali.com', 'ff6219f46bba77409f62fc8f016c1094', NULL, '3', 1),
(35, 32, 'Aashrita Goel', 7889398173, 'aashritagoel42@Gmali.com', 'f9f8393c7d8ce866f6e0bf8971537dd0', NULL, '3', 1),
(36, 33, 'Nibya Singh - 10187', 7781053168, 'singhnibya@Gmali.com', 'fd43da1ba6b02039e23ab22809cff799', NULL, '3', 1),
(37, 34, 'Nehal Bajaj', 8171853023, 'nehalbajaj@Gmali.com', '1b6eecd81e9db2aa8b754fa3b76c3104', NULL, '3', 1),
(38, 35, 'Anwesha Kedia', 9205060812, 'kediaanwesha@Gmali.com', 'f61a25ccbf2547e346b2e7fd04905197', NULL, '3', 1),
(39, 36, 'Shelly Tomar', 8218186911, 'shelltomarviiib@Gmali.com', 'b16a2f041532646fffb4de3e1c513823', NULL, '3', 1),
(40, 37, 'Kritika Kaushal', 8619545437, 'kritkakaushal1995@Gmali.com', '59f48b8470ae9f9a063a2209d1cfbaa3', NULL, '3', 1),
(41, 38, 'vivek sharma', 9811928163, 'viveksharma@Gmali.com', 'd9e689d962dd164cc35ebc5b9dbb1479', NULL, '3', 1),
(42, 39, 'Harshita Arora', 9839792113, 'harshitaarora@Gmali.com', 'd227f05f8cdb80eea53074146eed72c8', NULL, '3', 1),
(44, 4, 'Rajni Poddar', 9999098890, 'stayinclassluxurypg@gmail.com', 'f76d0e7f935a1753e740d61cda58f715', NULL, '1', 1),
(45, 41, 'Arpita Jaiswal', 7895884282, 'arpitajaiswal@Gmali.com', 'dbf2a38232640a2a6f0b218ddd8de3df', NULL, '3', 1),
(46, 42, 'jigyasaa', 9205071079, 'jigyasaa@Gmali.com', 'e5db50d6ab2759f53f9ae12685618d94', NULL, '3', 1),
(47, 5, 'Suresh Gupta', 9312360821, 'stayinclassluxurypg@gmail.com', '03416352b248edf0c2f3097002fb7b21', NULL, '1', 1),
(48, 43, 'Manish', 8249694186, 'manish@Gmali.com', '0005c8c56f78de3b692987744463020e', NULL, '3', 1),
(49, 44, 'Pooja Jayent Deshmukh', 8767351698, 'poojajayentdeshmuk@Gmali.com', '146bcbdb53b1ee29fa714ac3533fa5cc', NULL, '3', 1),
(50, 45, 'Visiting Guest', 10000, 'stayinclassluxurypg@gmail.com', 'b7a782741f667201b54880c925faec4b', NULL, '3', 1),
(51, 46, 'Shafali Bodoni', 9811608285, 'shafalibodoni@Gmali.com', 'eb4595a96aed8d74807b32bdc24d6aec', NULL, '3', 1),
(52, 47, 'Aporva Bhndari', 9416011400, 'aporvabhandari@gmail.com', 'c3bcceadfb29a03469ca2f2df03f9010', NULL, '3', 1),
(53, 48, 'Pooja', 8707341302, 'pooja@gmail.com', 'f7f18d35d75a071d7e85a96a60c22942', NULL, '3', 1),
(54, 49, 'Zeeshan kaskar', 9920797229, 'zeeshankaskar@Gmali.com', '158854c44af39205cc4e9248a3e045cf', NULL, '3', 1),
(55, 50, 'Akhilesh', 8130457598, 'Akhilesh@gmail.com', 'ccdc55a19d9dfa486386b3f6ab31372a', NULL, '3', 1),
(56, 51, 'V premchand', 7396785500, 'vpremchand@gmali.com', 'b1f84b431c7dc8bb574a83cdee9474fc', NULL, '3', 1),
(57, 52, 'Apoorva Jain', 8305805535, 'Apoorvajain@Gmail.com', '39e10434620df5d20384a132ef27239d', NULL, '3', 1),
(58, 53, 'Shahi', 8587003117, 'shahi@Gmali.com', '13e32a9e80f24f134b51b89f71f3dde3', NULL, '3', 1),
(59, 54, 'Ashish', 9854621345, 'ashish@Gmali.com', '9df416fd42f5923169a760f73ebdffca', NULL, '3', 1),
(60, 55, 'Nehal Bajaj', 8171853023, 'nehalbajaj@Gmali.com', '1b6eecd81e9db2aa8b754fa3b76c3104', NULL, '3', 1),
(61, 56, 'Soumya', 9586423463, 'soumya@Gmail.com', '2ecbcfcf0ba7a1b750b8e4b5c3c09063', NULL, '3', 1),
(62, 57, 'Hemant nagpal', 9513731225, 'hemantnagpal@Gmail.com', '933f7ef341d3682303957d99a4b69e9d', NULL, '3', 1);

-- --------------------------------------------------------

--
-- Table structure for table `note`
--

CREATE TABLE `note` (
  `id` int(11) NOT NULL,
  `date` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `note` text DEFAULT NULL,
  `description` text DEFAULT NULL,
  `status` int(11) NOT NULL,
  `createdat` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `note`
--

INSERT INTO `note` (`id`, `date`, `image`, `note`, `description`, `status`, `createdat`) VALUES
(1, '01-04-2020', 'uploads/5e8eea371d602_user_image.jpg', 'ajay work ', 'fdfdf', 1, '0000-00-00 00:00:00'),
(2, '03-04-2020', 'uploads/5e8ef5ed2f0be_download (2).jpg', 'sadsdfd', 'dfd', 1, '0000-00-00 00:00:00'),
(4, '07-04-2020', 'uploads/5e9887744f4d2_Food Menu.png', 'Food Menu', 'Food menu for the week 7 to the 14 April 2020', 1, '2020-04-16 16:27:32'),
(5, '08-04-2020', 'uploads/5e9888cab0f1c_Picture1.png', 'Food Menu', 'Food Menu for the week ', 2, '2020-04-16 16:33:14'),
(6, '14-04-2020', 'uploads/5e988d8c15c2f_Food Menu2.png', 'fm', 'fm', 1, '2020-04-16 16:53:32');

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `emp_id` int(11) NOT NULL,
  `payment` int(11) NOT NULL,
  `date` date DEFAULT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `payment_mode`
--

CREATE TABLE `payment_mode` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `payment_mode`
--

INSERT INTO `payment_mode` (`id`, `name`, `status`) VALUES
(1, 'Cash', 1),
(2, 'Phone pay', 1),
(3, 'Paytm', 1),
(5, 'Bank', 1);

-- --------------------------------------------------------

--
-- Table structure for table `refund`
--

CREATE TABLE `refund` (
  `id` int(11) NOT NULL,
  `emp_id` int(11) NOT NULL,
  `building_id` int(11) NOT NULL,
  `room_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `payment_type` int(11) DEFAULT NULL,
  `rent` int(11) NOT NULL,
  `amount` int(11) NOT NULL,
  `payment_mode` int(11) NOT NULL,
  `ref_no` bigint(20) DEFAULT NULL,
  `date` date NOT NULL,
  `comment` text NOT NULL,
  `status` int(11) NOT NULL,
  `delete_status` int(11) NOT NULL DEFAULT 1 COMMENT '2=delete',
  `reason` text NOT NULL,
  `createdat` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `refund_new`
--

CREATE TABLE `refund_new` (
  `id` int(11) NOT NULL,
  `emp_id` int(11) NOT NULL,
  `building_id` int(11) NOT NULL,
  `room_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `payment_type` int(11) NOT NULL,
  `amount` int(11) NOT NULL,
  `payment_mode` int(11) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp(),
  `comment` text NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `revenue`
--

CREATE TABLE `revenue` (
  `id` int(11) NOT NULL,
  `transaction_id` int(11) NOT NULL,
  `emp_id` int(11) NOT NULL,
  `building_id` int(11) NOT NULL,
  `room_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `rent` int(11) NOT NULL,
  `room_type` int(11) NOT NULL,
  `amount` int(11) NOT NULL,
  `payment_mode` int(11) NOT NULL,
  `ref_no` bigint(20) DEFAULT NULL,
  `date` date NOT NULL,
  `comment` text NOT NULL,
  `status` int(11) NOT NULL,
  `type` int(11) NOT NULL COMMENT '1=customer to employee 2=emp to Customer',
  `delete_status` int(11) NOT NULL DEFAULT 1 COMMENT '2=delete',
  `reason` text NOT NULL,
  `createdat` timestamp NOT NULL DEFAULT current_timestamp(),
  `date_diff` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `revenue`
--

INSERT INTO `revenue` (`id`, `transaction_id`, `emp_id`, `building_id`, `room_id`, `customer_id`, `rent`, `room_type`, `amount`, `payment_mode`, `ref_no`, `date`, `comment`, `status`, `type`, `delete_status`, `reason`, `createdat`, `date_diff`) VALUES
(1, 1, 3, 5, 125, 14, 15000, 1, 10000, 1, 0, '2020-08-10', 'reved viveka rant 10000', 0, 1, 1, '', '2020-08-29 15:48:16', 19),
(2, 2, 3, 2, 74, 38, 6000, 1, 878, 1, 0, '2020-08-16', 'Vivek Sharma Security Refand 878 .', 0, 2, 1, '', '2020-08-29 15:59:40', 13),
(3, 3, 3, 5, 130, 39, 11500, 1, 4000, 1, 0, '2020-08-21', 'Room Rent Full & Final 4000', 0, 1, 1, '', '2020-08-29 16:12:47', 8),
(4, 4, 3, 3, 87, 6, 6000, 1, 2000, 1, 0, '2020-08-26', 'Jyoti Awasthi new booking Token money 2000', 0, 1, 1, '', '2020-08-29 16:17:40', 3),
(5, 5, 3, 3, 88, 8, 5000, 1, 1000, 1, 0, '2020-08-26', 'Mahima new booking  token money 1000', 0, 1, 1, '', '2020-08-29 16:21:14', 3),
(7, 7, 3, 3, 85, 42, 10500, 1, 500, 1, 0, '2020-08-29', 'Jigyasaa 41G1F2 Security Refund', 0, 2, 1, '', '2020-08-31 07:20:15', 2),
(8, 8, 3, 3, 92, 2, 10000, 1, 10000, 1, 0, '2020-08-31', 'Vaishali  Rant 10000Rs Date 31-08-2020 \r\nB067R03', 0, 1, 1, '', '2020-08-31 16:00:13', 0),
(10, 10, 3, 6, 9, 41, 8500, 1, 88, 1, 0, '2020-09-01', 'Arpita Jaiswal security Refund Full and final 40C1 Date 01-09-2020', 0, 2, 1, '', '2020-09-01 11:07:51', 0),
(11, 11, 4, 3, 80, 11, 10000, 1, 4750, 5, 0, '2020-09-01', '', 0, 1, 2, 'Incorrect Date - Will repost for 7Aug2020', '2020-09-01 11:53:07', 0),
(12, 12, 4, 5, 140, 22, 9000, 1, 1000, 5, 0, '2020-09-01', '', 0, 1, 2, 'Incorrect Date - will repost', '2020-09-01 11:54:54', 0),
(13, 13, 3, 2, 68, 43, 7000, 1, 1000, 1, 0, '2020-09-04', 'new boking tokan money 1000Rs', 0, 1, 1, '', '2020-09-04 17:17:22', 0),
(14, 14, 3, 3, 93, 4, 8000, 1, 8000, 1, 0, '2020-09-04', 'Mohini Refund 8000', 0, 2, 1, '', '2020-09-04 17:19:39', 0),
(15, 15, 3, 3, 77, 44, 7000, 1, 2000, 1, 0, '2020-09-05', 'Pooja Jayent Deshmukh new booking Token money 2000Rs B067R06 date 05-09-2020', 0, 1, 1, '', '2020-09-05 06:14:09', 0),
(16, 16, 3, 3, 91, 1, 10000, 1, 11000, 1, 0, '2020-09-06', 'Saloni Rastogi Rant 11000 B067R07 date 06-09-2020', 0, 1, 1, '', '2020-09-06 07:40:56', 0),
(17, 17, 3, 3, 87, 6, 6000, 1, 6000, 1, 0, '2020-09-07', 'Jyoti Awasthi  Rant 41G1F3 .B067R08\r\nDate.07-09-2020', 0, 1, 1, '', '2020-09-07 14:55:16', 0),
(18, 18, 3, 5, 125, 14, 15000, 1, 17348, 1, 0, '2020-09-09', 'viveka shahi rant & washing machine 17348Rs B066R19  Date-09-09-2020', 0, 1, 1, '', '2020-09-09 16:19:16', 0),
(19, 19, 3, 5, 122, 46, 10000, 1, 120, 1, 0, '2020-09-10', '2 days Electicity  120Rs B066R20', 0, 1, 1, '', '2020-09-10 18:03:58', 0),
(20, 20, 2, 2, 74, 38, 6000, 1, 1020, 1, 0, '2020-08-04', 'Vivek sharma Ref no. B068R04', 0, 1, 1, '', '2020-09-23 17:37:43', 50),
(21, 21, 2, 2, 74, 38, 6000, 1, 1020, 1, 0, '2020-08-04', 'Vivek sharma Ref no. B068R04', 0, 1, 2, 'Duplicate Entry Posted (Entry no 20 was same as this)', '2020-09-23 17:37:43', 50),
(22, 22, 2, 3, 93, 4, 8000, 1, 2852, 1, 0, '2020-09-24', 'Mohini Yadav Refund 2852/-\r\nB067R10', 0, 2, 1, '', '2020-09-24 17:10:26', 0),
(23, 23, 2, 3, 95, 47, 9000, 1, 9000, 1, 0, '2020-09-24', 'B067R09..Cust Full and Final. Cust Paid rs9000 to Yogesh', 0, 1, 1, '', '2020-09-24 17:56:56', 0),
(24, 24, 2, 2, 59, 49, 9000, 1, 13500, 1, 0, '2020-10-02', 'Received cash from Zeeshan Kaskar 13500/- B046R27 ', 0, 1, 1, '', '2020-10-07 11:58:46', 5),
(25, 25, 2, 2, 58, 50, 9000, 1, 11500, 1, 0, '2020-10-30', 'Cash Received 11500 from Akhilesh B046R25', 0, 1, 1, '', '2020-10-07 12:08:17', 23),
(26, 26, 3, 2, 68, 43, 7000, 1, 104, 1, 0, '2020-10-05', 'Full & Final Received amount 104/- 05/10/2020', 0, 1, 1, '', '2020-10-08 17:24:19', 3),
(27, 27, 2, 3, 92, 2, 10000, 1, 10000, 1, 0, '2020-10-09', 'Vaisali rent 41G1S1 .10000 B066R21 by yogesh', 0, 1, 1, '', '2020-10-14 13:13:19', 5),
(28, 28, 2, 5, 125, 14, 15000, 1, 20500, 1, 0, '2020-10-11', 'viveka shahi rent 20500  B066R22 Yogesh', 0, 1, 1, '', '2020-10-14 13:43:18', 3),
(29, 29, 2, 2, 72, 51, 7000, 1, 2000, 1, 0, '2020-10-01', 'new boking v premchand 2000 B046R26 ', 0, 1, 1, '', '2020-10-14 17:34:20', 13),
(31, 31, 3, 2, 72, 51, 7000, 1, 3420, 1, 0, '2020-10-17', 'v premchand room rent 3420Rs B068R10', 0, 1, 1, '', '2020-10-20 10:08:20', 3),
(32, 32, 3, 5, 128, 52, 7000, 1, 1000, 1, 0, '2020-10-18', 'Apoorva jain  new boking 1000 B066R24 ', 0, 1, 1, '', '2020-10-20 10:16:13', 2),
(33, 33, 3, 3, 78, 10, 9000, 1, 9000, 1, 0, '2020-10-21', 'Deepti Singh Rent 9000B066R26', 0, 1, 1, '', '2020-10-27 06:55:32', 6),
(34, 34, 3, 5, 122, 53, 9500, 1, 2000, 1, 0, '2020-10-21', 'Shahni new boking 2000 B068R11', 0, 1, 1, '', '2020-10-27 07:02:46', 6),
(35, 35, 3, 5, 125, 14, 15000, 1, 19000, 1, 0, '2020-11-05', 'viveka shahi rent 19000 B067R11', 0, 1, 1, '', '2020-11-05 16:10:58', 0),
(36, 36, 2, 3, 91, 1, 10000, 1, 18432, 1, 0, '2020-10-20', 'Saloni Rastogi Rent 18432 B066R25', 0, 1, 1, '', '2020-11-06 16:08:51', 17),
(37, 37, 2, 2, 74, 54, 6500, 1, 1000, 1, 0, '2020-10-24', 'new booking Ashish tokan mony 1000', 0, 1, 1, '', '2020-11-06 16:16:44', 13),
(38, 38, 2, 5, 122, 53, 9500, 1, 7500, 1, 0, '2020-11-06', 'Shahi rent 7500 B068R13', 0, 1, 1, '', '2020-11-06 16:19:26', 0),
(39, 39, 2, 5, 131, 17, 12000, 1, 6000, 1, 0, '2020-10-31', 'Shaayal mishra Rent6000 B066R27', 0, 1, 1, '', '2020-11-06 16:28:39', 6),
(40, 40, 2, 2, 58, 50, 9000, 1, 10720, 1, 0, '2020-11-06', 'Akhilesh Rent 10720 B068R15', 0, 1, 1, '', '2020-11-06 16:30:54', 0),
(41, 41, 2, 2, 59, 49, 9000, 1, 13500, 1, 0, '2020-10-31', 'Zeeshan kaskar Rent 13500 B068R14', 0, 1, 1, '', '2020-11-06 16:34:29', 6),
(42, 42, 2, 1, 47, 55, 11500, 1, 2000, 1, 0, '2020-11-01', 'Nehal bajaj Full and final 2000 B066B28', 0, 1, 1, '', '2020-11-06 16:42:35', 5),
(43, 43, 2, 3, 92, 2, 10000, 1, 10000, 1, 0, '2020-11-01', 'Vaishali Rent 10000 B066R28', 0, 1, 1, '', '2020-11-06 16:44:36', 5),
(44, 44, 2, 3, 93, 4, 8000, 1, 13756, 1, 0, '2020-11-02', 'Mohini Yadav Refund 13756 B068R17', 0, 2, 1, '', '2020-11-06 16:47:30', 4),
(45, 45, 3, 3, 82, 56, 9000, 1, 2000, 1, 0, '2020-12-04', 'Luggage Charge', 0, 1, 1, '', '2020-12-21 07:48:59', 17),
(46, 46, 3, 2, 73, 57, 7000, 1, 10500, 1, 0, '2020-12-05', 'new boking Hemant nagpal 10500 B068R25', 0, 1, 1, '', '2020-12-21 08:00:48', 16),
(47, 47, 3, 5, 125, 14, 15000, 1, 17150, 1, 0, '2020-12-06', 'Viveka shahi Rent 17150 B067R13', 0, 1, 1, '', '2020-12-21 08:03:47', 15),
(48, 48, 3, 3, 91, 1, 10000, 1, 10000, 1, 0, '2020-12-06', 'Saloni rastogi Rent 10000 B067R14', 0, 1, 1, '', '2020-12-21 08:06:11', 15),
(49, 49, 3, 5, 137, 20, 17500, 1, 30000, 1, 0, '2020-12-07', 'Devangi garg full and final 30000 B067R15 date 07-12-20', 0, 1, 1, '', '2020-12-21 14:09:04', 14);

-- --------------------------------------------------------

--
-- Table structure for table `room_type`
--

CREATE TABLE `room_type` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `room_type`
--

INSERT INTO `room_type` (`id`, `name`, `status`) VALUES
(1, 'Pg', 1),
(2, 'Individual', 1),
(3, 'Personal', 1);

-- --------------------------------------------------------

--
-- Table structure for table `vender`
--

CREATE TABLE `vender` (
  `id` int(11) NOT NULL,
  `exep_category` int(11) NOT NULL,
  `vendor_name` varchar(255) NOT NULL,
  `vendor_type` int(11) NOT NULL,
  `vdor_business` varchar(255) NOT NULL,
  `building_id` int(11) NOT NULL,
  `date_of_onboarding` date NOT NULL,
  `date_of_leaving` date NOT NULL,
  `refrence_name` varchar(255) NOT NULL,
  `mobile` varchar(255) NOT NULL,
  `mobile2` varchar(255) NOT NULL,
  `landline` varchar(255) NOT NULL,
  `shop_address` text NOT NULL,
  `gst` int(11) NOT NULL,
  `stauts` int(11) NOT NULL,
  `createdat` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `vender`
--

INSERT INTO `vender` (`id`, `exep_category`, `vendor_name`, `vendor_type`, `vdor_business`, `building_id`, `date_of_onboarding`, `date_of_leaving`, `refrence_name`, `mobile`, `mobile2`, `landline`, `shop_address`, `gst`, `stauts`, `createdat`) VALUES
(1, 1, 'Naval Kishor (Jivan)', 0, 'Electrician ', 7, '2020-03-01', '1970-01-01', 'Mohit Sir', '8826419656', '8368119653', '', '143 Adarsh Kunj Barola Sector - 49\r\nNoida - 201301', 123456, 1, '2020-03-27 07:11:54'),
(2, 2, 'amar', 0, 'plumber', 0, '2020-04-08', '2020-04-08', 'cdfd', '9303119152', '9303119152', '35354', 'xfddf', 0, 1, '2020-04-08 09:50:37');

-- --------------------------------------------------------

--
-- Table structure for table `vender_type`
--

CREATE TABLE `vender_type` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `allotment`
--
ALTER TABLE `allotment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `building`
--
ALTER TABLE `building`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `buil_details`
--
ALTER TABLE `buil_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `complain`
--
ALTER TABLE `complain`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `com_category`
--
ALTER TABLE `com_category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `com_sub_category`
--
ALTER TABLE `com_sub_category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `emp_to_emp`
--
ALTER TABLE `emp_to_emp`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `expense`
--
ALTER TABLE `expense`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `expense_category`
--
ALTER TABLE `expense_category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `expense_subcategory`
--
ALTER TABLE `expense_subcategory`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `income_register`
--
ALTER TABLE `income_register`
  ADD PRIMARY KEY (`register_id`);

--
-- Indexes for table `invoice`
--
ALTER TABLE `invoice`
  ADD PRIMARY KEY (`invoice_id`);

--
-- Indexes for table `invoice_install`
--
ALTER TABLE `invoice_install`
  ADD PRIMARY KEY (`invoice_instaill_id`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `note`
--
ALTER TABLE `note`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `payment_mode`
--
ALTER TABLE `payment_mode`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `refund`
--
ALTER TABLE `refund`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `refund_new`
--
ALTER TABLE `refund_new`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `revenue`
--
ALTER TABLE `revenue`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `room_type`
--
ALTER TABLE `room_type`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `vender`
--
ALTER TABLE `vender`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `vender_type`
--
ALTER TABLE `vender_type`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `allotment`
--
ALTER TABLE `allotment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=55;

--
-- AUTO_INCREMENT for table `building`
--
ALTER TABLE `building`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `buil_details`
--
ALTER TABLE `buil_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=147;

--
-- AUTO_INCREMENT for table `complain`
--
ALTER TABLE `complain`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `com_category`
--
ALTER TABLE `com_category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `com_sub_category`
--
ALTER TABLE `com_sub_category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=58;

--
-- AUTO_INCREMENT for table `employee`
--
ALTER TABLE `employee`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `emp_to_emp`
--
ALTER TABLE `emp_to_emp`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=55;

--
-- AUTO_INCREMENT for table `expense`
--
ALTER TABLE `expense`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=174;

--
-- AUTO_INCREMENT for table `expense_category`
--
ALTER TABLE `expense_category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `expense_subcategory`
--
ALTER TABLE `expense_subcategory`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=59;

--
-- AUTO_INCREMENT for table `income_register`
--
ALTER TABLE `income_register`
  MODIFY `register_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=277;

--
-- AUTO_INCREMENT for table `invoice`
--
ALTER TABLE `invoice`
  MODIFY `invoice_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=164;

--
-- AUTO_INCREMENT for table `invoice_install`
--
ALTER TABLE `invoice_install`
  MODIFY `invoice_instaill_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=63;

--
-- AUTO_INCREMENT for table `note`
--
ALTER TABLE `note`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `payment`
--
ALTER TABLE `payment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `payment_mode`
--
ALTER TABLE `payment_mode`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `refund`
--
ALTER TABLE `refund`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `refund_new`
--
ALTER TABLE `refund_new`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `revenue`
--
ALTER TABLE `revenue`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;

--
-- AUTO_INCREMENT for table `room_type`
--
ALTER TABLE `room_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `vender`
--
ALTER TABLE `vender`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `vender_type`
--
ALTER TABLE `vender_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
